dmesg -t | grep -Ei "tevi|video|isi" > ~/dmesg.txt

# Registered mxc_isi.0.capture as /dev/video0
mxcLine=$(grep -m1 ${1} ~/dmesg.txt)
mxcSubstr=${mxcLine#*Registered }
mxcPrefix=${mxcSubstr%.capture*}

# created link [mxc-mipi-csi2.0] => [mxc_isi.0]
mipiLine=$(grep "${mxcPrefix}" ~/dmesg.txt | grep "mipi")
mipiSubstr=${mipiLine#*[}
mipiPrefix=${mipiSubstr%] =>*}

# created link [tevi-ap1302 1-003d] => [mxc-mipi-csi2.0]
teviLine=$(grep "${mipiPrefix}" ~/dmesg.txt | grep "tevi")
teviSubstr=${teviLine#*[}
teviPrefix=${teviSubstr%] =>*}

# 1
i2cSubstr=${teviPrefix#* } 
i2cNumber=${i2cSubstr%-*} 
echo $i2cNumber 
