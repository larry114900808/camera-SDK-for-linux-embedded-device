### [Download Sample Code Link](https://download.technexion.com/vizionViewer_SDK/) 

### [step1]:Open a terminal.
### [step2]: Run the following commands to install the necessary libraries

```shell
sudo apt update
sudo apt install build-essential make
sudo apt install make
sudo apt install cmake
sudo apt install libv4l-dev v4l-utils
sudo apt install gcc-aarch64-linux-gnu -y
sudo apt install g++-aarch64-linux-gnu -y
```


## To build the Sample code, please follow the steps below
### [step3]:Create a new directory for the build
```shell
mkdir build
cd build
```

### [step4]:Create a new directory for the buildCkeck your directory in 'build' and run the following commands to build the sample code.
```shell
cmake ..
```

### [step5]:Ckeck your directory 'build' whether the 'makefile' is generated.
```shell
make 
```


### [step6]:Execute the 'Sample' bin file  in the 'build' directory.
```shell
./Sample 
```

### [step7]:If the execution is completed, you will see:"++++Sample code test finish++++". And you will find the photo taken by the camera "image.raw" in the build directory.
