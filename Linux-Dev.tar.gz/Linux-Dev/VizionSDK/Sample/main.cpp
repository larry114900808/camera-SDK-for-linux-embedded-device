﻿#include <iostream>
#include <dlfcn.h>
#include <vector>
#include <string.h>
using namespace std;

enum class AE_MODE_STATUS
{
  MANUAL_EXP = 0,
  AUTO_EXP = 0xC,
};

enum class AWB_MODE_STATUS
{
  MANUAL_TEMPERATURE_WB = 0x7,
  AUTO_WB = 0xF,
};

enum class DZ_MODE_STATUS
{
  DZ_IMMEDIATE = 0x8000,
  DZ_SLOW = 0x0040,
  DZ_FAST = 0x0200,
};

enum VZ_IMAGE_FORMAT
{
  NONE = 0,
  YUY2,
  UYVY,
  NV12,
  MJPG,
};

struct VzFormat {
  uint8_t mediatype_idx;
  uint16_t width;
  uint16_t height;
  uint16_t framerate;
  VZ_IMAGE_FORMAT format;
};
enum CAPTURE_PROPETIES
{
  CAPTURE_BRIGHTNESS,
  CAPTURE_CONTRAST,
  CAPTURE_HUE,
  CAPTURE_SATURATION,
  CAPTURE_SHARPNESS,
  CAPTURE_GAMMA,
  CAPTURE_COLORENABLE,
  CAPTURE_WHITEBALANCE,
  CAPTURE_BACKLIGHTCOMPENSATION,
  CAPTURE_GAIN,
  CAPTURE_PAN,
  CAPTURE_TILT,
  CAPTURE_ROLL,
  CAPTURE_ZOOM,
  CAPTURE_EXPOSURE,
  CAPTURE_IRIS,
  CAPTURE_FOCUS,
  CAPTURE_PROP_MAX
};



class VizionCam;

typedef VizionCam* (*fpVcCreateVizionCamDevice)();
typedef int (*fpVcReleaseVizionCamDevice)(VizionCam*);
typedef int (*fpVcOpen)(VizionCam*, int dev_idx);
typedef int (*fpVcClose)(VizionCam*);
typedef int (*fpVcGetRawImageCapture)(VizionCam*, uint8_t*&, int* size, uint16_t);
typedef int (*fpVcGetCaptureFormatList)(VizionCam*, std::vector<VzFormat>&);
typedef int (*fpVcSetCaptureFormat)(VizionCam*, VzFormat);

typedef int (*fpVcGetAutoExposureMode)(VizionCam*, AE_MODE_STATUS&);
typedef int (*fpVcSetAutoExposureMode)(VizionCam*, AE_MODE_STATUS);
typedef int (*fpVcGetExposureTime)(VizionCam*, uint32_t&);
typedef int (*fpVcSetExposureTime)(VizionCam*, uint32_t);
typedef int (*fpVcGetExposureGain)(VizionCam*, uint8_t&);
typedef int (*fpVcSetExposureGain)(VizionCam*, uint8_t);
typedef int (*fpVcGetMaxFPS)(VizionCam*, uint8_t&);
typedef int (*fpVcSetMaxFPS)(VizionCam*, uint8_t);
typedef int (*fpVcGetAutoWhiteBalanceMode)(VizionCam*, AWB_MODE_STATUS&);
typedef int (*fpVcSetAutoWhiteBalanceMode)(VizionCam*, AWB_MODE_STATUS);
typedef int (*fpVcGetTemperature)(VizionCam*, uint16_t&);
typedef int (*fpVcSetTemperature)(VizionCam*, uint16_t);

typedef int (*fpVcGetGamma)(VizionCam*, double&);
typedef int (*fpVcSetGamma)(VizionCam*, double);
typedef int (*fpVcGetSaturation)(VizionCam*, double&);
typedef int (*fpVcSetSaturation)(VizionCam*, double);
typedef int (*fpVcGetContrast)(VizionCam*, double&);
typedef int (*fpVcSetContrast)(VizionCam*, double);
typedef int (*fpVcGetSharpening)(VizionCam*, double&);
typedef int (*fpVcSetSharpening)(VizionCam*, double);
typedef int (*fpVcGetDenoise)(VizionCam*, double&);
typedef int (*fpVcSetDenoise)(VizionCam*, double);

typedef int (*fpGetDigitalZoomType)(VizionCam*, DZ_MODE_STATUS&);
typedef int (*fpSetDigitalZoomType)(VizionCam*, DZ_MODE_STATUS);
typedef int (*fpGetDigitalZoomTarget)(VizionCam*, double&);
typedef int (*fpSetDigitalZoomTarget)(VizionCam*, double);

typedef int(*fpVcGetVideoDeviceList)(VizionCam*, std::vector<std::wstring>&);
typedef int (*fpVcGetVizionCamDeviceName)(VizionCam*, wchar_t*);
typedef int (*fpVcGetUniqueSensorID)(VizionCam*, char*);
typedef int (*fpVcGetUSBFirmwareVersion)(VizionCam*, char*);
typedef int (*fpVcClearISPBootdata)(VizionCam*);
typedef int (*fpVcDownloadBootdata)(VizionCam*,const char*);
typedef int (*fpVcGetPropertyRange)(VizionCam* , CAPTURE_PROPETIES , long& , long& , long& , long& , long& );
typedef int (*fpVcSetPropertyValue)(VizionCam*,CAPTURE_PROPETIES,long,int);
typedef int (*fpVcGetPropertyValue)(VizionCam*,CAPTURE_PROPETIES,long&,int&);





fpVcCreateVizionCamDevice VcCreateVizionCamDevice;
fpVcReleaseVizionCamDevice VcReleaseVizionCamDevice;
fpVcOpen VcOpen;
fpVcClose VcClose;
fpVcGetRawImageCapture VcGetRawImageCapture;
fpVcGetCaptureFormatList VcGetCaptureFormatList;
fpVcSetCaptureFormat VcSetCaptureFormat;

// AE.AWB
fpVcGetAutoExposureMode VcGetAutoExposureMode;
fpVcSetAutoExposureMode VcSetAutoExposureMode;
fpVcGetExposureTime VcGetExposureTime;
fpVcSetExposureTime VcSetExposureTime;
fpVcGetExposureGain VcGetExposureGain;
fpVcSetExposureGain VcSetExposureGain;
fpVcGetMaxFPS VcGetMaxFPS;
fpVcSetMaxFPS VcSetMaxFPS;
fpVcGetAutoWhiteBalanceMode VcGetAutoWhiteBalanceMode;
fpVcSetAutoWhiteBalanceMode VcSetAutoWhiteBalanceMode;
fpVcGetTemperature VcGetTemperature;
fpVcSetTemperature VcSetTemperature;
// Tunning
fpVcGetGamma		 VcGetGamma;
fpVcSetGamma		 VcSetGamma;
fpVcGetSaturation    VcGetSaturation;
fpVcSetSaturation    VcSetSaturation;
fpVcGetContrast      VcGetContrast;
fpVcSetContrast      VcSetContrast;
fpVcGetSharpening    VcGetSharpening;
fpVcSetSharpening    VcSetSharpening;
fpVcGetDenoise		 VcGetDenoise;
fpVcSetDenoise		 VcSetDenoise;

// Digital Zoom
fpGetDigitalZoomType   VcGetDigitalZoomType;
fpSetDigitalZoomType   VcSetDigitalZoomType;
fpGetDigitalZoomTarget VcGetDigitalZoomTarget;
fpSetDigitalZoomTarget VcSetDigitalZoomTarget;

fpVcGetVideoDeviceList VcGetVideoDeviceList;
fpVcGetVizionCamDeviceName VcGetVizionCamDeviceName;
fpVcGetUniqueSensorID VcGetUniqueSensorID;
fpVcGetUSBFirmwareVersion  VcGetUSBFirmwareVersion;
fpVcClearISPBootdata VcClearISPBootdata;
fpVcDownloadBootdata VcDownloadBootdata;
fpVcGetPropertyRange VcGetPropertyRange;
fpVcSetPropertyValue VcSetPropertyValue;
fpVcGetPropertyValue VcGetPropertyValue;









void*hs_vizionsdk;
AE_MODE_STATUS ae_mode;
AWB_MODE_STATUS awb_mode;
uint8_t max_fps = 0;
uint8_t exp_gain = 0;
uint32_t exp_time = 0;
uint16_t wb_temp = 0;

template <typename FP>
int LoadVcFunc(FP &fp, std::string func_name)
{
  fp = (FP)dlsym(hs_vizionsdk, func_name.c_str());
  if (NULL == fp) { printf("Load %s Fail\n", func_name.c_str()); return -1; }
  return 0;
}

int LoadVizionFunc()
{
  std::cout << "++++LoadVizionFunc++++" << std::endl;
  std::string libname("libVizionSDK.so");
  hs_vizionsdk =dlopen(libname.c_str(), RTLD_LAZY);
  const char* error = dlerror();
  if (error != nullptr) {
      std::cout << "dlopen error: " << error << std::endl;
    }
  if (LoadVcFunc(VcCreateVizionCamDevice, "VcCreateVizionCamDevice")) return -1;
  if (LoadVcFunc(VcReleaseVizionCamDevice, "VcReleaseVizionCamDevice")) return -1;
  if (LoadVcFunc(VcOpen, "VcOpen")) return -1;
  if (LoadVcFunc(VcClose, "VcClose")) return -1;
  if (LoadVcFunc(VcGetRawImageCapture, "VcGetRawImageCapture")) return -1;
  if (LoadVcFunc(VcGetCaptureFormatList, "VcGetCaptureFormatList")) return -1;
  if (LoadVcFunc(VcSetCaptureFormat, "VcSetCaptureFormat")) return -1;

  if (LoadVcFunc(VcGetAutoExposureMode, "VcGetAutoExposureMode")) return -1;
  if (LoadVcFunc(VcSetAutoExposureMode, "VcSetAutoExposureMode")) return -1;
  if (LoadVcFunc(VcGetExposureTime, "VcGetExposureTime")) return -1;
  if (LoadVcFunc(VcSetExposureTime, "VcSetExposureTime")) return -1;
  if (LoadVcFunc(VcGetExposureGain, "VcGetExposureGain")) return -1;
  if (LoadVcFunc(VcSetExposureGain, "VcSetExposureGain")) return -1;
  if (LoadVcFunc(VcGetMaxFPS, "VcGetMaxFPS")) return -1;
  if (LoadVcFunc(VcSetMaxFPS, "VcSetMaxFPS")) return -1;
  if (LoadVcFunc(VcGetAutoWhiteBalanceMode, "VcGetAutoWhiteBalanceMode")) return -1;
  if (LoadVcFunc(VcSetAutoWhiteBalanceMode, "VcSetAutoWhiteBalanceMode")) return -1;
  if (LoadVcFunc(VcGetTemperature, "VcGetTemperature")) return -1;
  if (LoadVcFunc(VcSetTemperature, "VcSetTemperature")) return -1;

  if (LoadVcFunc(VcGetGamma, "VcGetGamma")) return -1;
  if (LoadVcFunc(VcSetGamma, "VcSetGamma")) return -1;
  if (LoadVcFunc(VcGetSaturation, "VcGetSaturation")) return -1;
  if (LoadVcFunc(VcSetSaturation, "VcSetSaturation")) return -1;
  if (LoadVcFunc(VcGetContrast, "VcGetContrast")) return -1;
  if (LoadVcFunc(VcSetContrast, "VcSetContrast")) return -1;
  if (LoadVcFunc(VcGetSharpening, "VcGetSharpening")) return -1;
  if (LoadVcFunc(VcSetSharpening, "VcSetSharpening")) return -1;
  if (LoadVcFunc(VcGetDenoise, "VcGetDenoise")) return -1;
  if (LoadVcFunc(VcSetDenoise, "VcSetDenoise")) return -1;

  if (LoadVcFunc(VcGetDigitalZoomType, "VcGetDigitalZoomType")) return -1;
  if (LoadVcFunc(VcSetDigitalZoomType, "VcSetDigitalZoomType")) return -1;
  if (LoadVcFunc(VcGetDigitalZoomTarget, "VcGetDigitalZoomTarget")) return -1;
  if (LoadVcFunc(VcSetDigitalZoomTarget, "VcSetDigitalZoomTarget")) return -1;

  if (LoadVcFunc(VcGetVideoDeviceList, "VcGetVideoDeviceList")) return -1;
  if (LoadVcFunc(VcGetVizionCamDeviceName, "VcGetVizionCamDeviceName")) return -1;
  if (LoadVcFunc(VcGetUniqueSensorID, "VcGetUniqueSensorID")) return -1;
  if (LoadVcFunc(VcGetUSBFirmwareVersion, "VcGetUSBFirmwareVersion")) return -1;
  if (LoadVcFunc(VcClearISPBootdata, "VcClearISPBootdata")) return -1;
  if (LoadVcFunc(VcDownloadBootdata, "VcDownloadBootdata")) return -1;
  if (LoadVcFunc(VcGetPropertyRange, "VcGetPropertyRange")) return -1;
  if (LoadVcFunc(VcSetPropertyValue, "VcSetPropertyValue")) return -1;
  if (LoadVcFunc(VcGetPropertyValue, "VcGetPropertyValue")) return -1;

  std::cout << "++++LoadVizionFunc  finish++++" << std::endl;
  return 0;
}








int main() {
  std::cout << "++++Sample code test start++++" << std::endl;
  if (LoadVizionFunc() < 0) return -1;
  VizionCam* vizion_cam;

  vizion_cam=VcCreateVizionCamDevice();

  // Open the first UVC camera
  std::vector<std::wstring> devname_list;
  VcGetVideoDeviceList(vizion_cam, devname_list);
  for (const auto& device_name : devname_list) {
      std::wcout << device_name << std::endl;
    }
  VcGetVideoDeviceList(vizion_cam, devname_list);
  for (const auto& device_name : devname_list) {
      std::wcout << device_name << std::endl;
    }
  if (devname_list.empty()) {
      std::cout << "no camera connected." << std::endl;
      return -1;
    }


  if (VcOpen(vizion_cam, 0) < 0){
      std::cout << "Error opening camera" << std::endl;
      return -1;
    }
  std::cout << "opening camera finish" << std::endl;
  //get camera information
  wchar_t  wchstr[256];
  VcGetVizionCamDeviceName(vizion_cam, wchstr);
  std::wcout << L"Device Name: " << std::wstring(wchstr) << std::endl;

  char UID[1024];
  VcGetUniqueSensorID(vizion_cam,UID);
  std::cout << "UID::"<<UID << std::endl;



  //Get format list
  std::vector<VzFormat> capformats;
  VcGetCaptureFormatList(vizion_cam, capformats); // Get the available capture formats
  //Set format form list
  VzFormat format = capformats[7];
  std::cout << "format.framerate: " << format.framerate << std::endl;
  std::cout << "format.width: " << format.width << std::endl;
  std::cout << "format.height: " << format.height << std::endl;
  if(VcSetCaptureFormat(vizion_cam, format)!=0) return -1;

  // Capture Image
  int data_size = 0;
  int timeout = 3000;
  uint8_t* img_address;
  uint8_t* img_data = new uint8_t[format.width * format.height * 3];

  if(VcGetRawImageCapture(vizion_cam,img_address, &data_size, timeout) != 0) {
      std::cout << "Capture image fail" << std::endl;
    }
  std::cout << "Image data size: " << data_size << std::endl;
  memcpy(img_data, img_address, data_size);

  std::cout << "Capture image finish" << std::endl;


  // Camera Control
  ae_mode = AE_MODE_STATUS::MANUAL_EXP;
  VcSetAutoExposureMode(vizion_cam, ae_mode);
  VcGetAutoExposureMode(vizion_cam, ae_mode);

  if (ae_mode == AE_MODE_STATUS::AUTO_EXP) printf("Get AE Mode: AUTO_EXP\n");
  else if (ae_mode == AE_MODE_STATUS::AUTO_EXP) printf("Get AE Mode: MANUAL_EXP\n");

  max_fps = 60;
  VcSetMaxFPS(vizion_cam, max_fps); // Set max fps
  VcGetMaxFPS(vizion_cam, max_fps);
  printf("Get Max FPS: %d\n", max_fps);

  VcSetExposureTime(vizion_cam, 16667); // Set exp time 16667 us.  Range: 1 ~ 500000 us
  VcGetExposureTime(vizion_cam, exp_time);
  printf("Get AE Exposure Time: %d us\n", exp_time);

  VcSetExposureGain(vizion_cam, 3); // Set exp gain 3x.   Range: 1x ~ 64x
  VcGetExposureGain(vizion_cam, exp_gain);
  printf("Get Exp Gain: %d\n", exp_gain);

  awb_mode = AWB_MODE_STATUS::MANUAL_TEMPERATURE_WB;
  VcSetAutoWhiteBalanceMode(vizion_cam, awb_mode);
  VcGetAutoWhiteBalanceMode(vizion_cam, awb_mode);

  long min, max, step, def, caps,value;
  int flag = 0;

  std::cout << "CAPTURE_BRIGHTNESS: "  << std::endl;
  VcGetPropertyRange(vizion_cam,CAPTURE_BRIGHTNESS, min, max, step, def, caps);
  VcSetPropertyValue(vizion_cam,CAPTURE_BRIGHTNESS, 15,flag);
  VcGetPropertyValue(vizion_cam,CAPTURE_BRIGHTNESS, value,flag);
  flag=1;
  VcGetPropertyRange(vizion_cam,CAPTURE_WHITEBALANCE, min, max, step, def, caps);
  VcSetPropertyValue(vizion_cam,CAPTURE_WHITEBALANCE, 15000,flag);
  VcGetPropertyValue(vizion_cam,CAPTURE_WHITEBALANCE, value,flag);
  std::cout << "CAPTURE_WHITEBALANCE: "  << std::endl;

  VcGetPropertyRange(vizion_cam,CAPTURE_EXPOSURE, min, max, step, def, caps);
  VcSetPropertyValue(vizion_cam,CAPTURE_EXPOSURE, 10000,flag);
  VcGetPropertyValue(vizion_cam,CAPTURE_EXPOSURE, value,flag);
   std::cout << "CAPTURE_EXPOSURE: "  << std::endl;
  // Save the image
  FILE* fp = fopen("image.raw", "wb");
  fwrite(img_data, data_size, 1, fp);
  fclose(fp);
  std::cout << "Save image finish"  << std::endl;



//  VcClearISPBootdata(vizion_cam);
//  std::cout << "++++++++++++VcClearISPBootdata finish "<< std::endl;
//  const char* bin_path = "/home/larry/Vizioncam-bootdata/v3bootdata_AP1302-REV2-AR0521_rel428_800M.bin";
//  VcDownloadBootdata(vizion_cam,bin_path);
//   std::cout << "++++++++++++VcDownloadBootdata finish "<< std::endl;
//   char UID2[1024];
//   VcGetUniqueSensorID(vizion_cam,UID2);
//   std::cout << "UID2::"<<UID2 << std::endl;



  delete []img_data;
  VcClose(vizion_cam);
  std::cout << "Close the camera"  << std::endl;
  std::cout << "++++Sample code test finish++++" << std::endl;
  return 0;
}
