#include <fstream>
#include <vector>
#include <map>
#include <sys/mman.h>
#include <stdio.h>
#include <codecvt>
#include <unistd.h>
#include <stdlib.h>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <wchar.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sstream>
#include <fcntl.h>
#include <linux/videodev2.h>
#include <linux/uvcvideo.h>
#include <linux/usb/video.h>
#include <linux/v4l2-subdev.h>
#include <linux/dma-buf.h>
#include <errno.h>
#include <string.h>
#include "vizionsdk.h"
#include<thread>
#include <syslog.h>
#include <poll.h>
#include <pthread.h>
#include <stdbool.h>
#include <signal.h>
#include <stdint.h>
#include <chrono>
#include <unistd.h>
#include <linux/media.h>
#include <linux/v4l2-mediabus.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/fmt/ostr.h>
#include "spdlog/fmt/bin_to_hex.h"
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/sink.h>
#include <spdlog/sinks/daily_file_sink.h>
#include <spdlog/logger.h>
#include "../include/nlohmann/json.hpp"
#include <byteswap.h>
#include <libusb-1.0/libusb.h>
#include "cyusb.h"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <gst/video/video.h>
#include <gst/gstbuffer.h>
//#include <experimental/filesystem>


//Use Gstreamer streaming and appsink to get image buffer
//#define USE_GST_API

//Define support embedded system
//#define IMX
//#define Jetson


using json = nlohmann::json;

using namespace std::chrono;

#pragma comment(lib, "mf")
#pragma comment(lib, "mfplat")
#pragma comment(lib, "mfreadwrite")



//Macro to check the HR result
#define CHECK_HR_RESULT(hr, msg, ...) if (hr != S_OK) {printf("info: Function: %s, %s failed, Error code: 0x%.2x \n", __FUNCTION__, msg, hr, __VA_ARGS__); goto done; }

// GUID of the extension unit, {6FF33D97-7A1F-4C0D-B2D2-59FB178964C5}

#define CLEAR(a)            memset(&(a), 0, sizeof(a))
//#define SYNC_MODE

#define XU_I2C_CONTROL_MAX_TRANS_LENS  512
#define XU_I2C_CONTROL_MAX_DATA_LENS (XU_I2C_CONTROL_MAX_TRANS_LENS - 4)
#define XU_I2C_CONTROL_MAX_REG_ADDR_LENS 2

//Cypress define

#define FLASHPROG_VID		(0x04b4)	// USB VID for the FX3 flash programmer.

#define MAX_FWIMG_SIZE		(512 * 1024)	// Maximum size of the firmware binary.
#define MAX_WRITE_SIZE		(2 * 1024)	// Max. size of data that can be written through one vendor command.

#define I2C_PAGE_SIZE		(64)		// Page size for I2C EEPROM.
#define I2C_SLAVE_SIZE		(64 * 1024)	// Max. size of data that can fit on one EEPROM address.

#define SPI_PAGE_SIZE		(256)		// Page size for SPI flash memory.
#define SPI_SECTOR_SIZE		(64 * 1024)	// Sector size for SPI flash memory.

#define VENDORCMD_TIMEOUT	(5000)		// Timeout (in milliseconds) for each vendor command.
#define GETHANDLE_TIMEOUT	(5)		// Timeout (in seconds) for getting a FX3 flash programmer handle.

/* Utility macros. */
#define ROUND_UP(n,v)	((((n) + ((v) - 1)) / (v)) * (v))	// Round n upto a multiple of v.
#define GET_LSW(v)	((unsigned short)((v) & 0xFFFF))	// Get Least Significant Word part of an integer.
#define GET_MSW(v)	((unsigned short)((v) >> 16))		// Get Most Significant Word part of an integer.



//std::unique_ptr<VzLog> vzlog;
/*
 * Global variable definition
 */

static int g_num_planes;

//int selected_dev_idx=0;
//int mipi_cam_flag=0;

std::map<int, std::string> devicename_map;
std::map<int, std::string> hardwareid_map;
const std::string logconfig = "vzcfg.ini";
std::string logpath = "";
auto logger = spdlog::rotating_logger_mt("VizionSDK", logpath + "VizionSDK.log", 20971520, 3);

#define UVC_XU_ID 0x03        // XU_TERMINAL_ID
#define EU1_TEST_CMD 0x01      // XU_FIRMWARE_VERSION_CONTROL
#define EU1_TEST_CMD_LEN 0x04  // XU_FIRMWARE_VERSION_CONTROL DATA LENGTH
#define EU5_TEST_CMD 0x05      // XU_AP1302_I2C_CONTROL
#define EU5_TEST_CMD_LEN 0x05  // XU_AP1302_I2C_CONTROL DATA LENGTH
#define EU6_TEST_CMD 0x06  // XU_Gen_I2C_CONTROL
#define EU6_TEST_CMD_LEN 512 // XU_Gen_I2C_CONTROL DATA LENGTH

#define LOWBYTE(x)                                  ((unsigned char) (x))
#define HIGHBYTE(x)                                 ((unsigned char) (((unsigned int) (x)) >> 8))
#define CLEAR(a)                                    memset(&(a), 0, sizeof(a))
#define LI_XU_SENSOR_REG_RW_SIZE                    (5)
#define SENSOR_REG_WRITE_FLG                        (0)
#define SENSOR_REG_READ_FLG                         (1)


template <class T> void SafeRelease(T **ppT)
{
    if (*ppT) {
        (*ppT)->Release();
        *ppT = NULL;
    }
}
inline std::wstring s2ws(const std::string &str)
{
    using convert_typeX = std::codecvt_utf8<wchar_t>;
    std::wstring_convert<convert_typeX, wchar_t> converterX;

    return converterX.from_bytes(str);
}

inline std::string ws2s(const std::wstring &wstr)
{
    using convert_typeX = std::codecvt_utf8<wchar_t>;
    std::wstring_convert<convert_typeX, wchar_t> converterX;

    return converterX.to_bytes(wstr);
}


std::string m_FWDWNLOAD_ERROR_MSG[] = {
    "SUCCESS",
    "FAILED",
    "INVALID_MEDIA_TYPE",
    "INVALID_FWSIGNATURE",
    "DEVICE_CREATE_FAILED",
    "INCORRECT_IMAGE_LENGTH",
    "INVALID_FILE",
    "SPI_FLASH_ERASE_FAILED",
    "CORRUPT_FIRMWARE_IMAGE_FILE",
    "I2C_EEPROM_UNKNOWN_SIZE"
};






static int get_memory_map_info(struct VizionCam *vizion_cam)
{
    logger->info("Start get_memory_map_info");

    struct v4l2_buffer buf;
    struct v4l2_plane *planes;
    int fd = vizion_cam->fd;
    int ret, i, j;
    g_num_planes = 1;

    planes = (struct v4l2_plane *) malloc(g_num_planes * sizeof(*planes));

    if (!planes) {
        logger->error("alloc plane fail");
        free(planes);
        return -1;
    }

    for (i = 0; i < TEST_BUFFER_NUM; i++) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        memset(&buf, 0, sizeof(buf));
        memset(planes, 0, sizeof(*planes));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.m.planes = planes;
        buf.length = g_num_planes;
        buf.index = i;
        ret = ioctl(fd, VIDIOC_QUERYBUF, &buf);


        if (ret < 0) {
            logger->error("query buffer[{}] info fail, error: {}", i, strerror(errno));
            free(planes);
            return -1;
        }

        for (j = 0; j < g_num_planes; j++) {
            vizion_cam->buffers[i].planes[j].length = buf.m.planes[j].length;
            vizion_cam->buffers[i].planes[j].offset = (size_t)buf.m.planes[j].m.mem_offset;
            vizion_cam->buffers[i].planes[j].start = (uint8_t *)mmap(NULL,
                                                                     vizion_cam->buffers[i].planes[j].length,
                                                                     PROT_READ | PROT_WRITE, MAP_SHARED,
                                                                     fd, vizion_cam->buffers[i].planes[j].offset);



            if (vizion_cam->planes[i].start == MAP_FAILED) {
                logger->error("Error mapping plane, index: [{}], error: {}", j, strerror(errno));
                return -1;
            }
        }
    }

    free(planes);
    logger->info("Finish get_memory_map_info");
    return 0;
}

static int queue_buffer(int buf_id, struct VizionCam *vizion_cam)
{
   auto start_time1 = high_resolution_clock::now();
    int ret;
    vizion_cam->v4l2planes = (struct v4l2_plane *) malloc(g_num_planes * sizeof(*vizion_cam->v4l2planes));

    if (!vizion_cam->v4l2planes) {
        logger->error("queue_buffer alloc plane fail");
        return -ENOMEM;
    }


    g_num_planes = 1;
    vizion_cam->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    vizion_cam->buf.memory = V4L2_MEMORY_MMAP;
    vizion_cam->buf.index = buf_id;
    vizion_cam->buf.m.planes = vizion_cam->v4l2planes;
    vizion_cam->buf.length = g_num_planes;

//    buf.m.fd = vizion_cam->outdev_dmabuf_fd[buf_id];
//   // buf.length = vizion_cam->buffers[buf_id].length;
//    buf.bytesused = buf.length;



    for (int k = 0; k < g_num_planes; k++) {
        vizion_cam->buf.m.planes[k].length = vizion_cam->buffers[buf_id].planes[k].length;
        if (vizion_cam->buf.memory  == V4L2_MEMORY_MMAP) {
            vizion_cam->buf.m.planes[k].m.mem_offset =
                vizion_cam->buffers[buf_id].planes[k].offset;
        }
    }

    ret = ioctl(vizion_cam->fd, VIDIOC_QBUF, &vizion_cam->buf);
    if (ret < 0) {
        logger->error("buffer VIDIOC_QBUF error: {}", strerror(errno));
        free(vizion_cam->v4l2planes);
        return ret;
    }


    free(vizion_cam->v4l2planes);
    auto end_time1 = high_resolution_clock::now();
    auto duration1 = duration_cast<microseconds>(end_time1 - start_time1);
    printf("++++++++++++ ioctl VIDIOC_QBUF Execution time: %d microseconds \n",duration1.count());
    return 0;

}

static int dqueue_buffer(uint8_t *&img_data, struct VizionCam *vizion_cam)
{


    int fd = vizion_cam->fd;
    static int dot_count = 0;
    int ret = 0;
    g_num_planes = 1;
     vizion_cam->v4l2planes = (struct v4l2_plane *) malloc(g_num_planes * sizeof(* vizion_cam->v4l2planes));
    if (! vizion_cam->v4l2planes) {

        logger->error("alloc  plane fail\n: {}", strerror(errno));
        return -ENOMEM;
    }


    memset(& vizion_cam->buf, 0, sizeof( vizion_cam->buf));
     vizion_cam->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
     vizion_cam->buf.memory = V4L2_MEMORY_MMAP;
     vizion_cam->buf.m.planes =  vizion_cam->v4l2planes;
     vizion_cam->buf.length = g_num_planes;

    auto start_time1 = high_resolution_clock::now();

    ret = ioctl(fd, VIDIOC_DQBUF, & vizion_cam->buf);
    if (ret < 0) {
        logger->error("deqruery buffer info fail: {}", strerror(errno));
        free( vizion_cam->v4l2planes);
        return ret;
    }

    vizion_cam->cur_buf_id =  vizion_cam->buf.index;
    g_num_planes = 1;
    auto end_time1 = high_resolution_clock::now();
    auto duration1 = duration_cast<microseconds>(end_time1 - start_time1);
    printf("++++++++++++ ioctl VIDIOC_DQBUF Execution time: %d microseconds \n",duration1.count());

    //Copy image data


    for (int i = 0; i < g_num_planes; i++) {
        memcpy(img_data, vizion_cam->buffers[0].planes[i].start, vizion_cam->buffers[0].planes[i].plane_size);

    }

    // Use ptr to get image data

    //img_data = (uint8_t*)vizion_cam->buffers[0].planes[0].start;//(uint8_t*)buf.m.userptr;

//  printf("img_data address------------:%x  \n", img_data);
    free( vizion_cam->v4l2planes);
    return 0;

}


static int fill_video_channel(VizionCam *vizion_cam,
                              struct v4l2_format *fmt)
{
    int i, j;
    g_num_planes = 1;
    for (i = 0; i < 1; i++) {
        for (j = 0; j < g_num_planes; j++) {
            vizion_cam->buffers[i].planes[j].plane_size =
                fmt->fmt.pix_mp.plane_fmt[j].sizeimage;
        }
    }
    std::cout << ("fill_video_channel finish +++++++") << std::endl;
    return  0;
}
VIZION_API int VcMipiInit(VizionCam *vizion_cam)
{


    struct v4l2_buffer buf;
    struct v4l2_plane planes[NUM_PLANES];

    std::cout << "MipiInit start" << std::endl;
    int ret, i, j;



    // Request buffers
    memset(&vizion_cam->req, 0, sizeof(vizion_cam->req));
    vizion_cam->req.count = 3;
    vizion_cam->req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    vizion_cam->req.memory = V4L2_MEMORY_MMAP;





    if (ioctl(vizion_cam->fd, VIDIOC_REQBUFS, &vizion_cam->req) < 0) {
        std::cout << "Error requesting buffers" << strerror(errno) << std::endl;

        logger->error("Error requesting buffers\n: {}", strerror(errno));

        return -1;
    }

    //get_memory_map

    ret = get_memory_map_info(vizion_cam);



//    // V4L2 DMABuf export
//    struct v4l2_exportbuffer expbuf;
//    memset(&expbuf, 0, sizeof(expbuf));
//    for (int i = 0; i < vizion_cam->req.count; i++) {
//        printf("fd::%d\n", vizion_cam->fd);
//        CLEAR (expbuf);
//        expbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;//V4L2_BUF_TYPE_VIDEO_OUTPUT;
//        expbuf.index = i;
//        expbuf.flags = O_RDWR | O_CLOEXEC;
//        expbuf.plane = 0;
//        if (ioctl(vizion_cam->fd, VIDIOC_EXPBUF, &expbuf) == -1) {
//            perror("VIDIOC_EXPBUF::");
//            printf("%s\n", strerror(errno));
//            exit(EXIT_FAILURE);
//          }
//        //vizion_cam->buffers[i].length =vizion_cam->fmt.fmt.pix.sizeimage;
//        vizion_cam->outdev_dmabuf_fd[i] = expbuf.fd;
//        printf("Succeed to create %d dma buffers \n", i);
//        printf("dmafd=%d \n", expbuf.fd);
//      }
//    std::cout << "export dmafd finish" << std::endl;
    //queue_buffer
    for (j = 0; j < TEST_BUFFER_NUM; j++) {  //TEST_BUFFER_NUM
        ret = queue_buffer(j, vizion_cam);
        if (ret < 0) {
            std::cout << "Error querying buffer" << strerror(errno) << std::endl;

            logger->error("queuing buffer Fail\n: {}", strerror(errno));
            return ret;
        }
    }
    std::cout << "queue dmafd finish" << std::endl;
    // Start streaming
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    if (ioctl(vizion_cam->fd, VIDIOC_STREAMON, &type) < 0) {
        logger->error("Error starting stream \n: {}", strerror(errno));
        return -1;
    }
    std::cout << "MipiInit finish" << std::endl;

    return 0;

}
VIZION_API int VcInit(VizionCam *vizion_cam)
{



    std::cout << "Init start" << std::endl;
    int ret, i, j;

    // Request buffers
    memset(&vizion_cam->req, 0, sizeof(vizion_cam->req));

    vizion_cam->req.count = 3;
    vizion_cam->req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    vizion_cam->req.memory = V4L2_MEMORY_MMAP;



    if (ioctl(vizion_cam->fd, VIDIOC_REQBUFS, &vizion_cam->req) < 0) {
        std::cout << "Error requesting buffers" << std::endl;
        std::cout << "Error requesting buffers" << strerror(errno) << std::endl;
        logger->error("Error requesting buffers\n: {}", strerror(errno));
        return -1;
    }
    std::cout << "requesting buffers finish" << std::endl;


    // Query buffer
    memset(&vizion_cam->buf, 0, sizeof(vizion_cam->buf));
    vizion_cam->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    vizion_cam->buf.memory = V4L2_MEMORY_MMAP;
    vizion_cam->buf.index = 0;


    if (ioctl(vizion_cam->fd, VIDIOC_QUERYBUF, &vizion_cam->buf) < 0) {
        logger->error("queuing buffer Fail\n: {}", strerror(errno));
        std::cout << "Error querying buffer" << strerror(errno) << std::endl;

        return -1;
    }
    std::cout << "buf.length:" << vizion_cam->buf.length << std::endl;
    std::cout << "querying buffer finish" << std::endl;

    // Map buffer


    try {
        std::cout << "mapping start" << std::endl;
        std::cout << "fd" << vizion_cam->fd << std::endl;
        std::cout << "buf.m.offset" << vizion_cam->buf.m.offset << std::endl;


        vizion_cam->buff  = (uint8_t *)mmap(NULL, vizion_cam->buf.length, PROT_READ | PROT_WRITE, MAP_SHARED, vizion_cam->fd, vizion_cam->buf.m.offset);

    } catch (std::exception &e) {
        logger->error("query buffer[{}] info fail, error: {}", strerror(errno));
        std::cout << "exception: " << e.what() << "\n";
        std::cout << "Error mapping buffer" << strerror(errno) << std::endl;
        syslog(LOG_ERR, "Error mapping buffer: %s", strerror(errno));
    }

    if (vizion_cam->buffers == MAP_FAILED) {
        std::cout << "Error mapping buffer" << std::endl;
        std::cout << "Error mapping buffer" << strerror(errno) << std::endl;
        //return -1;
    }
    std::cout << "mapping buffer finish" << std::endl;




    // Queue buffer
    if (ioctl(vizion_cam->fd, VIDIOC_QBUF, &vizion_cam->buf) < 0) {
        std::cout << "Error queuing buffer" << std::endl;
        std::cout << "Error queuing buffer" << strerror(errno) << std::endl;
        return -1;
    }

    std::cout << "vizion_cam->fd:" << vizion_cam->fd << std::endl;
    std::cout << "queuing buffer finish" << std::endl;

    // Start streaming
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(vizion_cam->fd, VIDIOC_STREAMON, &type) < 0) {
        std::cout << "Error starting stream" << std::endl;
        std::cout << "Error starting stream" << strerror(errno) << std::endl;
        logger->error("Error starting stream \n: {}", strerror(errno));
        return -1;
    }
    std::cout << "Start streaming finish" << std::endl;


    std::cout << "Init finish" << std::endl;
    return 0;

}





VIZION_API int VcGetImageCapture(VizionCam *vizion_cam, uint8_t *img_data, uint16_t timeout)
{
    auto start_time = high_resolution_clock::now();

    int fd = vizion_cam->fd;
    int ret = 0;
    fd_set fds;
    struct timeval tv = {timeout / 1000, (timeout % 1000) * 1000};
    FD_ZERO(&fds);
    FD_SET(vizion_cam->fd, &fds);

    // Wait for image to be ready

    int r = select(vizion_cam->fd + 1, &fds, nullptr, nullptr, &tv);
    if (r == -1) {
        logger->error("Error in select\n: {}", strerror(errno));
        return -3;
    }
    if (r == 0) {
        logger->error("Timeout\n: {}", strerror(errno));
        return -2;
    }

    if (vizion_cam->mipi_cam_flag == 1) {
        // Dequeue buffer+Copy image data
        printf("Vc capture img_data+++:%x \n", img_data);
        if (ret = dqueue_buffer(img_data, vizion_cam) < 0) {
            logger->error("Dequeue buffer error\n: {}", strerror(errno));
            return -4;
        }
        ret = 0;
        // Enqueue buffer
        if (ret = queue_buffer(0, vizion_cam) < 0) {

            logger->error("Enqueue buffer error\n: {}", strerror(errno));
            return -4;
        }
    } else {

        std::cout << "Dequeue buffer start" << std::endl;
        // Dequeue buffer
        if (ioctl(vizion_cam->fd, VIDIOC_DQBUF, &vizion_cam->buf) < 0) {
            std::cout << "Error in dequeue buffer" << std::endl;
            logger->error("Dequeue buffer error\n: {}", strerror(errno));
            return -1;
        }
        std::cout << "Dequeue buffer finsh" << std::endl;
        // Copy image data

        memcpy(img_data, vizion_cam->buff, vizion_cam->buf.bytesused);

        std::cout << "finish Copy image data" << std::endl;
        // Enqueue buffer
        if (ioctl(vizion_cam->fd, VIDIOC_QBUF, &vizion_cam->buf) < 0) {
            std::cout << "Error in enqueue buffer" << std::endl;
            logger->error("Enqueue buffer error\n: {}", strerror(errno));
            return -1;
        }

    }

    //  std::cout << "finish VcGetImageCapture" << std::endl;
    auto end_time = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(end_time - start_time);
    printf("++++++++++++ VcGetImageCapture Execution time: %d microseconds", duration.count());
    return 0;
}

int VizionCam:: GetRawImageCapture(uint8_t*& raw_data, int* data_size, uint16_t timeout){


  GSret = gst_element_get_state(pipeline, &state, &pending,3 * GST_SECOND);// GST_CLOCK_TIME_NONE);
  if (GSret == GST_STATE_CHANGE_SUCCESS) {
//      std::cout << "GST_STATE_CHANGE_SUCCESS" << std::endl;
    // 成功获取状态
  } else if (GSret == GST_STATE_CHANGE_FAILURE) {
      std::cout << " GST_STATE_CHANGE_FAILURE" << std::endl;
      logger->error("GST_STATE_CHANGE_FAILURE\n: {}", strerror(errno));
      return VZ_CAM_OCCUPIED;
    // 获取状态失败
  } else if (GSret == GST_STATE_CHANGE_NO_PREROLL) {
      std::cout << " GST_STATE_CHANGE_NO_PREROLL" << std::endl;
      logger->error("GST_STATE_CHANGE_NO_PREROLL\n: {}", strerror(errno));
    // 状态无法预滚动
  } else if (GSret == GST_STATE_CHANGE_ASYNC) {
      std::cout << " GST_STATE_CHANGE_ASYNC" << std::endl;
      logger->error("GST_STATE_CHANGE_ASYNC\n: {}", strerror(errno));
        return VZ_TIMEOUT;
      // 异步状态改变中

    }


  if (state == GST_STATE_PLAYING) {

    } else if (state == GST_STATE_VOID_PENDING) {
      std::cout << "Pipeline is GST_STATE_VOID_PENDING" << std::endl;
      logger->error("Pipeline is GST_STATE_VOID_PENDING");
      return VZ_TIMEOUT;
    }else if (state == GST_STATE_NULL) {
      std::cout << "Pipeline is GST_STATE_NULL" << std::endl;
      logger->error("Pipeline is GST_STATE_NULL");
      return VZ_OTHER_ERROR;
    }else if (state == GST_STATE_READY) {
      std::cout << "Pipeline is GST_STATE_READY" << std::endl;
    }else if (state == GST_STATE_PAUSED) {
      std::cout << "Pipeline is GST_STATE_PAUSED" << std::endl;
      logger->error("Pipeline is GST_STATE_PAUSED");
       return VZ_CAM_OCCUPIED;
    }




  GstBuffer * GSbuffer=nullptr ;
  GstSample *GSsample=nullptr ;
  GstMapInfo GSmap;
//  fd_set fds;
// struct timeval tv = {timeout / 1000, (timeout % 1000) * 1000};
// FD_ZERO(&fds);
// FD_SET(fd, &fds);
// // Wait for image to be ready

// int r = select(fd + 1, &fds, nullptr, nullptr, &tv);

// if (r == 0) {
//     if(timeout_counter>2){
//         std::cout << "VZ_FAIL" << std::endl;
//         logger->error("VZ_FAIL\n: {}", strerror(errno));
//         return VZ_FAIL;
//       }else{
//         std::cout << "Timeout" << std::endl;
//         gst_buffer_unmap(GSbuffer, &GSmap);
//         gst_sample_unref(GSsample);
//         std::cout << "Timeout and restart" << std::endl;
//         gst_element_set_state(pipeline, GST_STATE_NULL);
//         gst_object_unref(pipeline);
//         std::cout << "Timeout and Close" << std::endl;
//         SetCaptureFormat(setcapformat);
//         std::cout << "Timeout and SetCaptureFormat" << std::endl;
//         timeout_counter++;
//         return VZ_TIMEOUT;

//       }
//   }
  try{
    auto start_time = high_resolution_clock::now();
    GSsample = gst_app_sink_try_pull_sample(GST_APP_SINK(sink), timeout * 1000 *1000);
    // GSsample = gst_app_sink_pull_sample(GST_APP_SINK(sink));
   // 檢查sample是否為有效對象
   if (GSsample != nullptr && GST_IS_SAMPLE(GSsample)) {
       // 取得buffer
       GSbuffer = gst_sample_get_buffer(GSsample);
       // 檢查buffer是否為有效對象
       if (GSbuffer != NULL && GSbuffer != nullptr && GST_IS_BUFFER(GSbuffer)) {
           // 進行相應的操作
           gst_buffer_map(GSbuffer, &GSmap, GST_MAP_READ);
           //memcpy(raw_data, GSmap.data, GSmap.size);
          raw_data=GSmap.data;
           *data_size=GSmap.size;
           // 釋放buffer的資源
           gst_buffer_unmap(GSbuffer, &GSmap);
           gst_sample_unref(GSsample);
       } else {
           // 處理buffer為空或無效的情況
           std::cout << "buffer為空或無效" << std::endl;
           gst_sample_unref(GSsample);
           return VZ_OTHER_ERROR;
       }
   } else {
       // 處理sample為空或無效的情況
       gst_sample_unref(GSsample);
       std::cout << "sample is invaild" << std::endl;


       if (gst_app_sink_is_eos(GST_APP_SINK(sink))){
           return VZ_OTHER_ERROR;

         }

       return VZ_TIMEOUT;
   }

   auto end_time = high_resolution_clock::now();
   auto duration = duration_cast<microseconds>(end_time - start_time);
  printf("++++++++++++ VcGetRawImageCapture Gstreamer Execution time: %d microseconds \n",duration.count());

  } catch(const std::exception& e) {
   logger->error("[%s][%d] GetageCapture Fail!. %s", __FUNCTION__, __LINE__, e.what());
   std::cout << "[%s][%d]  GetageCapture unexpectFail!. %s" <<  e.what() << std::endl;
   Close();
   return -1;

 }

  return 0;
}

VIZION_API int VcGetRawImageCapture(VizionCam *vizion_cam, uint8_t *& raw_data, int *data_size, uint16_t timeout)
{

#ifdef USE_GST_API
  return vizion_cam->GetRawImageCapture(raw_data, data_size, timeout);

#else


auto start_time = high_resolution_clock::now();
    fd_set fds;
    struct timeval tv = {timeout / 1000, (timeout % 1000) * 1000};
    FD_ZERO(&fds);
    FD_SET(vizion_cam->fd, &fds);
    // Wait for image to be ready

    int r = select(vizion_cam->fd + 1, &fds, nullptr, nullptr, &tv);

    if (r == -1) {
        logger->error("Error in select\n: {}", strerror(errno));
        std::cout << "Error in select:" << strerror(errno) << std::endl;
        return VZ_CAM_OCCUPIED;
    }

    if (r == 0) {
        std::cout << "Timeout" << std::endl;
        logger->error("Timeout\n: {}", strerror(errno));
        return VZ_TIMEOUT;
    }


    int ret = 0;
    if (vizion_cam->mipi_cam_flag == 1) {
        // Dequeue buffer+Copy image data


        ret = dqueue_buffer(raw_data, vizion_cam);

        // Enqueue buffer
        ret = queue_buffer(0, vizion_cam);

        *data_size = vizion_cam->buffers[0].planes[0].plane_size;
        int ret = 0;
    } else {
        // Dequeue buffer
        if (ioctl(vizion_cam->fd, VIDIOC_DQBUF, &vizion_cam->buf) < 0) {
            logger->error("Dequeue buffer error\n: {}", strerror(errno));
            return VZ_CAPTURE_FORMAT_ERROR;
        }
        // Copy image data
        memcpy(raw_data, vizion_cam->buff, vizion_cam->buf.bytesused);
        *data_size = vizion_cam->buf.bytesused;
        // Enqueue buffer
        if (ioctl(vizion_cam->fd, VIDIOC_QBUF, &vizion_cam->buf) < 0) {
            std::cout << "Error in enqueue buffer" << std::endl;
            logger->error("Enqueue buffer error\n: {}", strerror(errno));
            return VZ_CAPTURE_FORMAT_ERROR;
        }

    }

    auto end_time = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(end_time - start_time);
   printf("++++++++++++ VcGetRawImageCapture dqueue_buffer&queue_buffer Execution time: %d microseconds \n",duration.count());

      return 0;
  #endif




}

int VizionCam::SetCaptureFormat(VzFormat capformat){


  fd_set fds;
 struct timeval tv = {5000 / 1000, (5000 % 1000) * 1000};
 FD_ZERO(&fds);
 FD_SET(fd, &fds);
 // Wait for image to be ready

 int r = select(fd + 1, &fds, nullptr, nullptr, &tv);

 if (r == 0) {
    std::cout << "SetCaptureFormat timeout " << std::endl;
     return VZ_TIMEOUT;
   }


  GMainLoop *loop;
  setcapformat=capformat;
  /* 初始化 GStreamer */
  gst_init(NULL, NULL);
  loop = g_main_loop_new(NULL, FALSE);


  /* 創建元件 */
  pipeline = gst_pipeline_new("camera-pipeline");
  src = gst_element_factory_make("v4l2src", "camera-source");

  sink = gst_element_factory_make("appsink", "VizionSDK-sink");


  /* 檢查元件是否創建成功 */
  if (!pipeline || !src || !sink) {
    g_printerr("One or more elements could not be created. Exiting.\n");
    return -1;
  }

  /* 設置 v4l2src 的屬性 */
  gchar *g_object_device_path = g_strdup_printf("/dev/video%d", dev_idx);
  g_object_set(G_OBJECT(src), "device", g_object_device_path, NULL);// "io-mode", 4,
  g_object_set(G_OBJECT(sink), "max-buffers", 6, "drop", FALSE, "emit-signals", TRUE, NULL);
  g_object_set(G_OBJECT(sink), "sync", FALSE, NULL);
  /* 創建輸出格式 */
//  std::cout << "GSTcapformat.format: " << capformat.format << std::endl;
//  std::cout << "GSTcapformat.width: " << capformat.width << std::endl;
//   std::cout << "GSTcapformat.heigh: " << capformat.height << std::endl;
//  std::cout << "GSTcapformat.framerate: " << capformat.framerate << std::endl;

  gchar *g_object_format;
  switch (capformat.format) {
  case VZ_IMAGE_FORMAT::UYVY:
      g_object_format= g_strdup_printf("UYVY");
      break;
  case VZ_IMAGE_FORMAT::YUY2:
      g_object_format= g_strdup_printf("YUY2");
      break;
  case VZ_IMAGE_FORMAT::NV12:
      g_object_format= g_strdup_printf("NV12");
      break;
  case VZ_IMAGE_FORMAT::MJPG:
      g_object_format= g_strdup_printf("MJPG");
      break;
  default:
      g_object_format= g_strdup_printf("UYVY");
      break;
  }
//  std::cout << "g_object_format: " << g_object_format << std::endl;

  if(capformat.format==4){
      caps = gst_caps_new_simple("image/jpeg",
        "width", G_TYPE_INT, capformat.width,
        "height", G_TYPE_INT, capformat.height,
        "framerate", GST_TYPE_FRACTION,capformat.framerate, 1,
        NULL);
//       std::cout << "image/jpeg " << std::endl;

    }else{
      caps = gst_caps_new_simple("video/x-raw",
        "format", G_TYPE_STRING, g_object_format,
        "width", G_TYPE_INT, capformat.width,
        "height", G_TYPE_INT, capformat.height,
        "framerate", GST_TYPE_FRACTION,capformat.framerate, 1,
        NULL);

    }

  /* 設置 appsink 屬性 */
//  gst_app_sink_set_max_buffers(GST_APP_SINK(sink), 2);
////  if(mipi_cam_flag==1 && capformat.width*capformat.height<2304001){
////      gst_app_sink_set_drop(GST_APP_SINK(sink), TRUE);
//////      std::cout << "Drop true "  << std::endl;
////    }else{
////      gst_app_sink_set_drop(GST_APP_SINK(sink), FALSE);
//////      std::cout << "Drop FALSE "  << std::endl;
////    }
//     gst_app_sink_set_drop(GST_APP_SINK(sink), FALSE);
//    gst_app_sink_set_emit_signals(GST_APP_SINK(sink), 0);


  /* 將元件添加到管道中 */

  gst_bin_add_many(GST_BIN(pipeline), src,sink, NULL);


//  /* 連接元件 */
  if (!gst_element_link_filtered(src, sink, caps)) {
    g_printerr("Failed to link elements. Exiting.\n");
    gst_object_unref(pipeline);
    return -1;
  }

  /* 啟動管道 */
//  GstState state;

  gst_element_set_state(pipeline, GST_STATE_PLAYING);

  std::this_thread::sleep_for(std::chrono::milliseconds(1000));

  return 0;

}

VIZION_API int VcSetCaptureFormat(VizionCam *vizion_cam, VzFormat capformat)
{

#ifdef USE_GST_API
  return vizion_cam->SetCaptureFormat(capformat);


#else


    int ch_id;
    struct v4l2_format fmt;
    struct v4l2_streamparm stream_parm;

    memset(&vizion_cam->fmt, 0, sizeof(vizion_cam->fmt));
    memset(&stream_parm, 0, sizeof(stream_parm));
    if (vizion_cam->mipi_cam_flag == 1) {
        vizion_cam->fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
        stream_parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    } else {

        vizion_cam->fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        stream_parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    }
    vizion_cam->fmt.fmt.pix.width = capformat.width;//1280;//
    vizion_cam->fmt.fmt.pix.height = capformat.height; //720;//


    std::cout << "+++++++++++++++" << std::endl;
    stream_parm.parm.capture.timeperframe.numerator = 1; //capformat.framerate;
    std::cout << "---------------" << std::endl;
    stream_parm.parm.capture.timeperframe.denominator = capformat.framerate;
    std::cout << "+++++++++++++++" << std::endl;

    switch (capformat.format) {
    case VZ_IMAGE_FORMAT::UYVY:
        vizion_cam->fmt.fmt.pix.pixelformat = V4L2_FORMAT::UYVY;
        break;
    case VZ_IMAGE_FORMAT::YUY2:
        vizion_cam->fmt.fmt.pix.pixelformat = V4L2_FORMAT::YUYV;
        break;
    case VZ_IMAGE_FORMAT::NV12:
        vizion_cam->fmt.fmt.pix.pixelformat = V4L2_FORMAT::NV12;
        break;
    case VZ_IMAGE_FORMAT::MJPG:
        vizion_cam->fmt.fmt.pix.pixelformat = V4L2_FORMAT::MJPG;
        break;
    default:
        vizion_cam->fmt.fmt.pix.pixelformat = V4L2_FORMAT::UYVY;
        break;
    }
    vizion_cam->fmt.fmt.pix.field = V4L2_FIELD_NONE;

    //std::cout << "capformatwidth: " << capformat.width << std::endl;
    printf("Printf capformatwidth:%d \n", capformat.width);
    //std::cout << "capformatheight: " << capformat.height << std::endl;
    printf("Printf capformatheight:%d \n", capformat.height);
    //std::cout << "capformat.pixelformat: " << vizion_cam->fmt.fmt.pix.pixelformat<< std::endl;
    printf("Printf capformatpixelformat:%d \n", vizion_cam->fmt.fmt.pix.pixelformat);
    std::cout << "capformat.framerate: " << capformat.framerate << std::endl;

    if (ioctl(vizion_cam->fd, VIDIOC_S_FMT, &vizion_cam->fmt) < 0) {
        std::cout << "Error setting format" << std::endl;
        std::cout << "Error setting format" << strerror(errno) << std::endl;
        return -1;
    }


    std::cout << "setting setting finish" << std::endl;
    if (ioctl(vizion_cam->fd, VIDIOC_S_PARM, &stream_parm) < 0) {
        std::cout << "Error set framerate fail" << strerror(errno) << std::endl;
        std::cout << "set framerate fail" << std::endl;
        //return -1;
    }
    std::cout << "setting framerate finish" << std::endl;
    if (ioctl(vizion_cam->fd, VIDIOC_G_FMT, &vizion_cam->fmt) < 0) {
        std::cout << "Error Getting format" << std::endl;
        std::cout << "Error Getting format" << strerror(errno) << std::endl;
        return -1;
    }
    std::cout << "getting setting finish" << std::endl;

    if (vizion_cam->mipi_cam_flag == 1) {
        int ret = VcMipiInit(vizion_cam);
        if (ret < 0) {
            std::cout << "Error VcMipiInit camera:" << strerror(errno) << std::endl;
            return -1;
        }
        fill_video_channel(vizion_cam, &vizion_cam->fmt);
    } else {

        int ret = VcInit(vizion_cam);
        if (ret < 0) {
            std::cout << "Error VcInit camera:" << strerror(errno) << std::endl;
            return -1;
        }

    }

    return 0;
#endif

}


VIZION_API VizionCam *VcCreateVizionCamDevice()
{
    VizionCam *vizion_cam = new VizionCam();

    return  vizion_cam;
}
int VcReleaseVizionCamDevice(VizionCam* vizion_cam)
{
	if (vizion_cam != nullptr)
	{
		delete vizion_cam;
		vizion_cam = nullptr;
	}
	return 0;
}
VizionCam::VizionCam()
{
    logger->info("++++start++++++");
    //GetVideoDevices();
    dev_idx = -1;
    is_auto_ae = false;
    is_auto_awb = false;
}
VizionCam::VizionCam(uint8_t dev_idx)
{
    logger->info("++++++++++");
    //GetVideoDevices();
    this->dev_idx = dev_idx;

    is_auto_ae = false;
    is_auto_awb = false;
}

VizionCam::~VizionCam()
{
    //    if (pCallback != nullptr) { pCallback->Release(); pCallback = nullptr; }
    //    if (pVideoSource != nullptr) { SafeRelease(&pVideoSource); pVideoSource = nullptr; }
    //    if (pVideoConfig != nullptr) { SafeRelease(&pVideoConfig); pVideoConfig = nullptr; }
    //    if (pVideoReader != nullptr) { SafeRelease(&pVideoReader); pVideoReader = nullptr; }
    //    if (ppVideoDevices != nullptr) {
    //        for (int i = 0; i < this->noOfVideoDevices; i++)
    //            SafeRelease(&ppVideoDevices[i]);
    //        CoTaskMemFree(ppVideoDevices);
    //    }
    logger->info("++++++++++");
}
int GetVideoDevices(void)
{
    int fd = -1;
    int device_index = 0;
    char device_name[32];

    devicename_map.clear();
    hardwareid_map.clear();

    for (;;) {
        sprintf(device_name, "/dev/video%d", device_index);
        fd = open(device_name, O_RDWR | O_NONBLOCK);
        if (fd == -1) {
            break;
        }

        struct v4l2_capability cap;
        if (ioctl(fd, VIDIOC_QUERYCAP, &cap) == -1) {
            close(fd);
            device_index++;
            continue;
        }

        devicename_map[device_index] = (char *)cap.card;
        hardwareid_map[device_index] = device_name;

        close(fd);
        device_index++;
    }

    return device_index;
}





int VizionCam::Open(int list_idx)
{
    // Open the camera device
    char device_name[20];
    i2c_idx = -1;
    char device_type = dev_map[list_idx].type;
    if (device_type == 'm') {
        // mipi cam
        mipi_cam_flag = 1;

    } else if (device_type == 'u') {
        // usb cam
        mipi_cam_flag = 0;
    }
    logger->info("mipi_cam_flag: {}", mipi_cam_flag);



    if (mipi_cam_flag == 1) {


//        std::string cmd = "journalctl -b |grep 003 |grep mxc-mipi-csi2."+std::to_string(dev_map[list_idx].index);
//        std::cout << "Output cmd: " << cmd << "\n";
//        std::string i2c_info = {""};
//        FILE *fp = popen(cmd.c_str(), "r");
//        if (fp == nullptr) {
//            std::cout << "cmd error" << std::endl;
//            logger->error("I2C cmd error\n: {}  ", strerror(errno));
//            return -1;
//        }

//         char *buf = nullptr;
//        size_t bufsize = 0;
//        std::string first_line;

//        if (getline(&buf, &bufsize, fp) != -1) {
//            first_line = buf;
//        }
//            std::size_t pos = first_line.find("-003");
//            if (pos != std::string::npos ) {
//                i2c_info = first_line.substr(pos -1, 1);
//                std::cout << "i2c_info::" << i2c_info << std::endl;
//              }

//        pclose(fp);

        i2c_idx  = dev_map[list_idx].dev_i2c_idx;
//        std::cout << " i2c_idx: " << i2c_idx << "\n";
        logger->info("Getvideo i2c_idx: {}",i2c_idx);
        if(i2c_idx==-1){
            std::cout << " i2c load or driver not set /i2c_idx:" << i2c_idx << std::endl;
            logger->error("i2c load or driver not set /i2c_idx: {}",i2c_idx);
          }


    }


    sprintf(device_name, "/dev/video%d", dev_map[list_idx].index);
    fd = open(device_name, O_RDWR | O_NONBLOCK, 0);


    if (fd < 0) {
        std::cout << "Error opening device" << std::endl;
        return -1;
    }
    dev_idx = dev_map[list_idx].index;
    logger->info("Open selected_dev_idx: {}", dev_idx);

//    std::string dev_name1 = dev_map[list_idx].dev_name;
//    std::cout << "--dev_name1::" << dev_name1 << std::endl;
//    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
//    std::wstring wdev_name = converter.from_bytes(dev_name1);
    // dev_name = converter.to_bytes(wdev_name);
    //dev_name = wdev_name;
    //dev_name.assign(dev_map[list_idx].wdev_name);
    dev_name = dev_map[list_idx].wdev_name;


    return mipi_cam_flag;

}

int VizionCam::Close()
{

#ifdef USE_GST_API
  try{
    if (pipeline) {
          gst_element_set_state(pipeline, GST_STATE_NULL);
          gst_object_unref(pipeline);
      }

    // Stop pipeline and release resources
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

  }catch(...){
    std::cout << "Error closing pipeline" << std::endl;
  }

#else
    if (mipi_cam_flag == 1) {
        int type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
        if (ioctl(fd, VIDIOC_STREAMOFF, &type) < 0) {
            logger->error("Error stopping stream");
            return -1;
        }

        // Unmap buffer
        for (int i = 0; i < TEST_BUFFER_NUM; i++) {
            for (int k = 0; k < g_num_planes; k++) {
                munmap(buffers[i].planes[k].start,
                       buffers[i].planes[k].length);

            }
        }

        std::cout << "Vc Mipi close" << std::endl;
    } else {


        int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl(fd, VIDIOC_STREAMOFF, &type) < 0) {
            std::cout << "Error stopping stream" << std::endl;
            logger->error("Error stopping stream");
            return -1;
        }

        // Unmap buffer
        if (munmap(buff, buf.length) < 0) {
            std::cout << "Error unmapping buffer" << std::endl;
            return -1;
        }

        std::cout << "Vc USB close" << std::endl;
    }
 #endif
    if (close(fd) < 0) {
        std::cout << "Error closing file descriptor" << std::endl;
        logger->error("Error closing file descriptor");
        return -1;
    }

    return 0;
}


int VizionCam::GetMipiDeviceName(){

#ifdef IMX

  for(int a=0;a<8;a++){
      uint8_t data[64];
      char device_name[64];
      if(I2CHeaderReadname(a,0x54, 2, 0x0002, 64, data)==0){
          if(data[0]==0x00){
              I2CHeaderReadname(a,0x54, 2, 0x0003, 64, data);

            }

          int i = 0, j = 0;

          while (i < 64 && j < 63  &&isprint(data[i])) {

                  device_name[j] = data[i];
                  i++;
                  j++;

          }

          device_name[j] = '\0';

          if(a==1){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
//                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);/*
                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;*/
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
//                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
//                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[0]= std::string(device_name);
              std::transform( product_info[0].begin(),  product_info[0].end(),  product_info[0].begin(), ::toupper);
              i2c_index[0]="1";

            }
          if(a==4){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
//                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);
//                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
//                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
//                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[1]= std::string(device_name);
              std::transform( product_info[1].begin(),  product_info[1].end(),  product_info[1].begin(), ::toupper);
              i2c_index[1]="4";
            }

        }

    }
#endif
#ifdef HMI_IM8

  for(int a=0;a<8;a++){
      uint8_t data[64];
      char device_name[64];
      if(I2CHeaderReadname(a,0x54, 2, 0x0002, 64, data)==0){
          if(data[0]==0x00){
              I2CHeaderReadname(a,0x54, 2, 0x0003, 64, data);

            }

          int i = 0, j = 0;

          while (i < 64 && j < 63  &&isprint(data[i])) {

                  device_name[j] = data[i];
                  i++;
                  j++;

          }

          device_name[j] = '\0';

          if(a==4){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
//                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);/*
                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;*/
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
//                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
//                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[0]= std::string(device_name);
              std::transform( product_info[0].begin(),  product_info[0].end(),  product_info[0].begin(), ::toupper);
              i2c_index[0]="4";

            }
          if(a==1){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
//                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);
//                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
//                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
//                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[1]= std::string(device_name);
              std::transform( product_info[1].begin(),  product_info[1].end(),  product_info[1].begin(), ::toupper);
              i2c_index[1]="1";
            }

        }

    }
#endif
#ifdef IM8_BB

  for(int a=1;a<3;a++){
      uint8_t data[64];
      char device_name[64];
      if(I2CHeaderReadname(a,0x54, 2, 0x0002, 64, data)==0){
          if(data[0]==0x00){
              I2CHeaderReadname(a,0x54, 2, 0x0003, 64, data);

            }

          int i = 0, j = 0;

          while (i < 64 && j < 63  &&isprint(data[i])) {

                  device_name[j] = data[i];
                  i++;
                  j++;

          }

          device_name[j] = '\0';

          if(a==1){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);/*
                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;*/
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[3]= std::string(device_name);
              std::transform( product_info[3].begin(),  product_info[3].end(),  product_info[3].begin(), ::toupper);
              i2c_index[3]="1";

            }
          if(a==2){

              if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
                  mipi_cam_flag=1;
                  if(data[0]==0x02){
                      std::cout << "header 2" << std::endl;
                      i2c_idx=a;
                      VzHeader header;
                      GetBootdataHeader(&header);
                      std::cout << "header->product_name 2:"<<header.product_name << std::endl;
                      std::memcpy(device_name, header.product_name, sizeof(device_name));


                    }else if(data[0]==0x03){
                      std::cout << "header 3" << std::endl;
                      i2c_idx=a;
                      VzHeaderV3 headerv3;
                     GetBootdataHeaderV3(&headerv3);
                      std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
                      std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

                    }
                  mipi_cam_flag=0;
                }

              product_info[4]= std::string(device_name);
              std::transform( product_info[4].begin(),  product_info[4].end(),  product_info[4].begin(), ::toupper);
              i2c_index[4]="2";
            }

        }

    }
#endif



#ifdef Jetson
  int i=0;
  for(int a=7;a<9;a++){
      uint8_t data[64];
      char device_name[64];


      if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
          mipi_cam_flag=1;
          if(data[0]==0x02){
//              std::cout << "header 2" << std::endl;
              i2c_idx=a;
              VzHeader header;
              GetBootdataHeader(&header);
//              std::cout << "header->product_name 2:"<<header.product_name << std::endl;
              std::memcpy(device_name, header.product_name, sizeof(device_name));


            }else if(data[0]==0x03){
//              std::cout << "header 3" << std::endl;
              i2c_idx=a;
              VzHeaderV3 headerv3;
              GetBootdataHeaderV3(&headerv3);
//              std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
              std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

            }
          mipi_cam_flag=0;
          product_info[i]= std::string(device_name);
          std::transform( product_info[i].begin(),  product_info[i].end(),  product_info[i].begin(), ::toupper);
          i2c_index[i]= std::to_string(a);
          i++;

        }
//    std::cout << "a::"<<a << std::endl;
    }


#endif

#ifdef Xavier
  int i=0;
  for(int a=30;a<35;a++){
      uint8_t data[64];
      char device_name[64];


      if(I2CHeaderReadname(a,0x54, 2, 0x0000, 2, data)==0){
          mipi_cam_flag=1;
          if(data[0]==0x02){
//              std::cout << "header 2" << std::endl;
              i2c_idx=a;
              VzHeader header;
              GetBootdataHeader(&header);
//              std::cout << "header->product_name 2:"<<header.product_name << std::endl;
              std::memcpy(device_name, header.product_name, sizeof(device_name));


            }else if(data[0]==0x03){
//              std::cout << "header 3" << std::endl;
              i2c_idx=a;
              VzHeaderV3 headerv3;
              GetBootdataHeaderV3(&headerv3);
//              std::cout << "header->product_name 3:"<<headerv3.product_name << std::endl;
              std::memcpy(device_name, headerv3.product_name, sizeof(device_name));

            }
          mipi_cam_flag=0;
          product_info[i]= std::string(device_name);
          std::transform( product_info[i].begin(),  product_info[i].end(),  product_info[i].begin(), ::toupper);
          i2c_index[i]= std::to_string(a);
          i++;

        }
//    std::cout << "a::"<<a << std::endl;
    }



#endif


   return 0;
}


int VizionCam::GetVideoDeviceList(std::vector<std::wstring> &devname_list)
{
  //std::cout << ("GetVideoDeviceList star") << std::endl;
  int uvc_counter = 0;
    devname_list.clear();
    dev_map.clear();




    std::wstring dev_info;

//Get  dev_name &push back
    for (int i = 0; i < NUM_SENSORS; i++) {//NUM_SENSORS
        char dev_name[100];
        sprintf(dev_name, "/dev/video%d", i);
        int fd1 = 0;
        if (!mipi_dev_map.empty()) {
            // mipi_dev_map 不為空，可以存取其元素
//            std::cout << "mipi_dev_map.size: " <<mipi_dev_map.size()<< std::endl;
            bool allNotEqual = true;
            for (int j = 0; j < mipi_dev_map.size(); j++)
              {
                if (mipi_dev_map[j].index == i) {
                    allNotEqual = false;
//                    std::cout << "j: " <<j << std::endl;
//                    std::cout << "mipi_dev_map[j].index : " <<mipi_dev_map[j].index << std::endl;
                    break;
                }
            }

            if (allNotEqual) {
                // mipi_dev_map[0] 到 mipi_dev_map[15] 都不等於 i
                fd1 = open(dev_name, O_RDONLY);
//                std::cout << "open in i: " << i << std::endl;
            } else {
//                std::cout << "i found in mipi_dev_map" << std::endl;
            }

        }else{
            fd1 = open(dev_name, O_RDONLY);
//            std::cout << "open  i: " << i << std::endl;
          }

        if (fd1 > 0) {
            v4l2_capability cap;
            if (ioctl(fd1, VIDIOC_QUERYCAP, &cap) == 0) {
                char *char_array = reinterpret_cast<char *>(cap.card);


                std::string str(char_array);
                std::wstring wstr(str.begin(), str.end());


                if (str.find("isi-cap") != std::string::npos ||str.find("vi-output") != std::string::npos) {
                    if(get_mipi_name==0){
                        fd=fd1;
                        GetMipiDeviceName();
                        fd=0;
                        get_mipi_name=1;
                      }


                   // dev_info = L"/dev/video" + std::to_wstring(i) + L"(" + std::wstring(product_info[i].begin(), product_info[i].end()) + L")" ;

                    dev_info =  std::wstring(product_info[i].begin(), product_info[i].end())+L"(" + + L"/dev/video" + std::to_wstring(i)+ L")" ; //+ wstr+L":"+std::wstring(product_info[i].begin(), product_info[i].end())+ L")" ;
                    //devname_list.push_back(dev_info);
                    //logger->info("Mipi Device: {}" ,dev_info);
                    std::string w_to_str(dev_info.begin(), dev_info.end());
                    char str_to_char[100];
                    std::strcpy(str_to_char, w_to_str.c_str());
                    VizionCam::DeviceInfo new_dev = { i, 'm' };

                    strcpy(new_dev.dev_name, str_to_char);

                   if(product_info[i]!=""){
                     new_dev.dev_i2c_idx= std::stoi(i2c_index[i]);
                     }
                    std::wstring w_dev_name(product_info[i].begin(), product_info[i].end()); // 转换为 std::wstring
                    new_dev.wdev_name = w_dev_name;
                    //wcsncpy(new_dev.dev_name, dev_info.c_str(), sizeof(new_dev.dev_name) / sizeof(wchar_t));
                    //dev_map.push_back(new_dev);
                    mipi_dev_map.push_back(new_dev);

                } else if (str.find("m2m") != std::string::npos) {
                    //dev_info = L"/dev/video" + std::to_wstring(i) + L"(" +std::wstring(product_info[i].begin(), product_info[i].end())+ L")" ;//+ wstr+L":"+std::wstring(product_info[i].begin(), product_info[i].end())+ L")" ;

                } else {
#ifdef IMX
                    if (uvc_counter % 2 == 0)
#endif
#ifdef HMI_IM8
                    if (uvc_counter % 2 == 0)
#endif
#ifdef IM8_BB
                    if (uvc_counter % 2 == 0)
#endif
#ifdef Jetson
                    if (uvc_counter % 1 == 0)
#endif
#ifdef Xavier
                    if (uvc_counter % 1 == 0)
#endif
                      {
                        //dev_info = L"/dev/video" + std::to_wstring(i) + L"(" + wstr + L")";
                        dev_info =   wstr  + L"("+L"/dev/video" + std::to_wstring(i)+ L")";
                        //devname_list.push_back(dev_info);

                        std::string w_to_str(dev_info.begin(), dev_info.end());
                        char str_to_char[100];
                        std::strcpy(str_to_char, w_to_str.c_str());
                        VizionCam::DeviceInfo new_dev = { i, 'u'};
                        strcpy(new_dev.dev_name, str_to_char);


                        new_dev.wdev_name = wstr;
                        //wcsncpy(new_dev.dev_name, dev_info.c_str(), sizeof(new_dev.dev_name) / sizeof(wchar_t));
                        dev_map.push_back(new_dev);
                    }
                    uvc_counter = uvc_counter + 1;
                }


                close(fd1);
            }
        }
    }
    dev_map.insert(dev_map.begin(), mipi_dev_map.begin(), mipi_dev_map.end());
    for (const auto& device : dev_map) {
//           std::cout << "Index: " << device.index << std::endl;
//           std::cout << "Type: " << device.type << std::endl;
//           std::cout << "dev_i2c_idx: " << device.dev_i2c_idx << std::endl;
//           std::cout << "dev_name: " << device.dev_name << std::endl;
//           std::wcout << "wdev_name: " << device.wdev_name << std::endl;
//           std::cout << std::endl;
           dev_info=  device.wdev_name+L"(" + L"/dev/video" + std::to_wstring(device.index)+ L")" ;
           devname_list.push_back(dev_info);

       }


    return 0;

}

int VizionCam::GetCaptureFormatList(std::vector<VzFormat> &capformats)
{
    v4l2_capability cap;
    v4l2_fmtdesc fmtdesc;
    v4l2_frmivalenum frmival;
    v4l2_frmsizeenum frmsize;
    std::wstring descript;
    int i;
    int fd_v4l = 0;
    char v4l_name[20];

    try{
        capformats.clear();
        snprintf(v4l_name, sizeof(v4l_name), "/dev/video%d", dev_idx);
        if ((fd_v4l = open(v4l_name, O_RDWR, 0)) < 0) {
            std::cout << ("unable to open %s for capture device\n", v4l_name) << std::endl;
        } else {
            std::cout << ("open video device %s\n", v4l_name) << std::endl;
        }

        if (ioctl(fd_v4l, VIDIOC_QUERYCAP, &cap) == 0) {
             logger->info("Capabilities: {}" ,cap.capabilities);
            if (cap.capabilities) {
                fmtdesc.index = 0;

                if ((cap.capabilities & 0x00001000)) {
                    fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;//#define V4L2_CAP_VIDEO_CAPTURE_MPLANE	0x00001000

                } else if (cap.capabilities & 0x00000001) {

                    fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;//#define V4L2_CAP_VIDEO_CAPTURE	0x00000001

                }

                while (ioctl(fd_v4l, VIDIOC_ENUM_FMT, &fmtdesc) >= 0) {

//                    std::cout << "Format name: " << fmtdesc.description << std::endl;

                    frmsize.pixel_format = fmtdesc.pixelformat;

                    frmsize.index = 0;
                    if(ioctl(fd_v4l, VIDIOC_ENUM_FRAMESIZES, &frmsize) < 0){

                        std::cout << " VIDIOC_ENUM_FRAMESIZES  fail" << std::endl;
                        return -1;
                      }
                    while (ioctl(fd_v4l, VIDIOC_ENUM_FRAMESIZES, &frmsize) >= 0) {
                        frmival.index = 0;
                        frmival.pixel_format = fmtdesc.pixelformat;
                        frmival.width = frmsize.discrete.width;
                        frmival.height = frmsize.discrete.height;
                        if(ioctl(fd_v4l, VIDIOC_ENUM_FRAMEINTERVALS, &frmival) < 0){
                            std::cout << " VIDIOC_ENUM_FRAMEINTERVALS  fail" << std::endl;
                            return -1;
                          }
                        while (ioctl(fd_v4l, VIDIOC_ENUM_FRAMEINTERVALS, &frmival) >= 0) {
                            VzFormat format;
                            format.width = (uint16_t)frmsize.discrete.width;
                            format.height = (uint16_t)frmsize.discrete.height;
                            format.framerate = (uint16_t)frmival.discrete.denominator/frmival.discrete.numerator;
                            switch (fmtdesc.pixelformat) {
                            case V4L2_FORMAT::UYVY:
                                format.format = VZ_IMAGE_FORMAT::UYVY;
                                break;
                            case V4L2_FORMAT::YUYV:
                                format.format = VZ_IMAGE_FORMAT::YUY2;
                                break;
                            case V4L2_FORMAT::NV12:
                                format.format = VZ_IMAGE_FORMAT::NV12;
                                break;
                            case V4L2_FORMAT::MJPG:
                                format.format = VZ_IMAGE_FORMAT::MJPG;//MJPG
                                break;
                            default:
                                format.format = VZ_IMAGE_FORMAT::NONE;
                                break;
                            }
//                            std::cout <<("format.format")<<format.format<<std::endl;
//                            std::cout << ("Pixelformat=") << std::dec <<fmtdesc.pixelformat<< std::endl;
//                            std::cout << ("width=") <<format.width << std::endl;
//                            std::cout << ("height=") << format.height << std::endl;
//                            std::cout << ("framerate=") << format.framerate<< std::endl;

                            capformats.push_back(format);
                            frmival.index++;
                        }
                        frmsize.index++;
                    }
                    fmtdesc.index++;
                }
            }
        }
        close(fd_v4l);
    }catch (std::exception &e) {
      logger->error("[%s][%d] GetCaptureFormatList Fail!. %s", __FUNCTION__, __LINE__, e.what());
      std::cout << "[%s][%d] GetCaptureFormatList Fail!. %s" <<  e.what() << std::endl;
      return -1;
  }
    return 0;
}






int VizionCam::LoadProfileSetting(const char *profile_str)
{
    json profile = json::parse(profile_str);

    try {

        vzprof.profilename = profile["ProfileName"];
        vzprof.productname = profile["ProductName"];
        vzprof.gendate = profile["GenerateDate"];
        vzprof.UID = profile["UID"];
        vzprof.controlmode = profile["ControlMode"];
        auto cameraconfig = profile["CameraProfile"];
        vzprof.camprofile.width = cameraconfig["Width"];
        vzprof.camprofile.height = cameraconfig["Height"];
        vzprof.camprofile.framerate = cameraconfig["Framerate"];
        vzprof.camprofile.pixelformat_str = cameraconfig["PixelFormat"];
        if (vzprof.camprofile.pixelformat_str == "UYVY")
            vzprof.camprofile.format = UYVY;
        else if (vzprof.camprofile.pixelformat_str == "YUY2")
            vzprof.camprofile.format = YUY2;
        else if (vzprof.camprofile.pixelformat_str == "MJPG")
            vzprof.camprofile.format = MJPG;
        else if (vzprof.camprofile.pixelformat_str == "NV12")
            vzprof.camprofile.format = NV12;
        else
            vzprof.camprofile.format = NONE;
        auto uvcconfig = profile["UVCProfiles"];

        vzprof.uvcprofile.exp_auto = uvcconfig["Exp_Auto"];
        vzprof.uvcprofile.exposure = uvcconfig["Exposure"];
        vzprof.uvcprofile.gain = uvcconfig["Gain"];
        vzprof.uvcprofile.wb_auto = uvcconfig["WB_Auto"];
        vzprof.uvcprofile.temperature = uvcconfig["Temperature"];
        vzprof.uvcprofile.zoom = uvcconfig["Zoom"];
        vzprof.uvcprofile.pan = uvcconfig["Pan"];
        vzprof.uvcprofile.tilt = uvcconfig["Tilt"];
        vzprof.uvcprofile.brightness = uvcconfig["Brightness"];
        vzprof.uvcprofile.contrast = uvcconfig["Contrast"];
        vzprof.uvcprofile.saturation = uvcconfig["Saturation"];
        vzprof.uvcprofile.sharpness = uvcconfig["Sharpness"];
        vzprof.uvcprofile.gamma = uvcconfig["Gamma"];

        auto ispconfig = profile["ISPProfiles"];
        vzprof.ispprofile.ae_exp_mode = ispconfig["AE_EXP_MODE"];
        vzprof.ispprofile.ae_exp_time = ispconfig["AE_EXP_TIME"];
        vzprof.ispprofile.ae_ex_gain = ispconfig["AE_EXP_GAIN"];
        vzprof.ispprofile.awb_mode = ispconfig["AWB_MODE"];
        vzprof.ispprofile.awb_temp = ispconfig["AWB_TEMP"];
        vzprof.ispprofile.zoom_target = ispconfig["ZoomTarget"];
        vzprof.ispprofile.zoom_ctx = ispconfig["Zoom_CTX"];
        vzprof.ispprofile.zoom_cty = ispconfig["Zoom_CTY"];
        vzprof.ispprofile.brightness = ispconfig["Brightness"];
        vzprof.ispprofile.contrast = ispconfig["Contrast"];
        vzprof.ispprofile.saturation = ispconfig["Saturation"];
        vzprof.ispprofile.sharpmess = ispconfig["Sharpness"];
        vzprof.ispprofile.gamma = ispconfig["Gamma"];
        vzprof.ispprofile.denoise = ispconfig["Denoise"];
        vzprof.ispprofile.flipmode = ispconfig["Flip_Mode"];
        vzprof.ispprofile.effectmode = ispconfig["Effect_Mode"];
    } catch (std::exception &e) {
        logger->error("[%s][%d] LoadProfileSetting Fail!. %s", __FUNCTION__, __LINE__, e.what());
        std::cout << "[%s][%d] LoadProfileSetting Fail!. %s" <<  e.what() << std::endl;
        return -1;
    }

    return 0;
}


int VizionCam::LoadProfileSettingFromPath(const char *profile_path)
{
    std::ifstream file(profile_path);
    json profile = json::parse(file);

    try {
        vzprof.profilename = profile["ProfileName"];
        vzprof.productname = profile["ProductName"];
        vzprof.gendate = profile["GenerateDate"];
        vzprof.UID = profile["UID"];
        vzprof.controlmode = profile["ControlMode"];

        auto cameraconfig = profile["CameraProfile"];
        vzprof.camprofile.width = cameraconfig["Width"];
        vzprof.camprofile.height = cameraconfig["Height"];
        vzprof.camprofile.framerate = cameraconfig["Framerate"];
        vzprof.camprofile.pixelformat_str = cameraconfig["PixelFormat"];
        if (vzprof.camprofile.pixelformat_str == "UYVY")
            vzprof.camprofile.format = UYVY;
        else if (vzprof.camprofile.pixelformat_str == "YUY2")
            vzprof.camprofile.format = YUY2;
        else if (vzprof.camprofile.pixelformat_str == "MJPG")
            vzprof.camprofile.format = MJPG;
        else if (vzprof.camprofile.pixelformat_str == "NV12")
            vzprof.camprofile.format = NV12;
        else
            vzprof.camprofile.format = NONE;

        auto uvcconfig = profile["UVCProfiles"];
        vzprof.uvcprofile.exp_auto = uvcconfig["Exp_Auto"];
        vzprof.uvcprofile.exposure = uvcconfig["Exposure"];
        vzprof.uvcprofile.gain = uvcconfig["Gain"];
        vzprof.uvcprofile.wb_auto = uvcconfig["WB_Auto"];
        vzprof.uvcprofile.temperature = uvcconfig["Temperature"];
        vzprof.uvcprofile.zoom = uvcconfig["Zoom"];
        vzprof.uvcprofile.pan = uvcconfig["Pan"];
        vzprof.uvcprofile.tilt = uvcconfig["Tilt"];
        vzprof.uvcprofile.brightness = uvcconfig["Brightness"];
        vzprof.uvcprofile.contrast = uvcconfig["Contrast"];
        vzprof.uvcprofile.saturation = uvcconfig["Saturation"];
        vzprof.uvcprofile.sharpness = uvcconfig["Sharpness"];
        vzprof.uvcprofile.gamma = uvcconfig["Gamma"];

        auto ispconfig = profile["ISPProfiles"];
        vzprof.ispprofile.ae_exp_mode = ispconfig["AE_EXP_MODE"];
        vzprof.ispprofile.ae_exp_time = ispconfig["AE_EXP_TIME"];
        vzprof.ispprofile.ae_ex_gain = ispconfig["AE_EXP_GAIN"];
        vzprof.ispprofile.awb_mode = ispconfig["AWB_MODE"];
        vzprof.ispprofile.awb_temp = ispconfig["AWB_TEMP"];
        vzprof.ispprofile.zoom_target = ispconfig["ZoomTarget"];
        vzprof.ispprofile.zoom_ctx = ispconfig["Zoom_CTX"];
        vzprof.ispprofile.zoom_cty = ispconfig["Zoom_CTY"];
        vzprof.ispprofile.brightness = ispconfig["Brightness"];
        vzprof.ispprofile.contrast = ispconfig["Contrast"];
        vzprof.ispprofile.saturation = ispconfig["Saturation"];
        vzprof.ispprofile.sharpmess = ispconfig["Sharpness"];
        vzprof.ispprofile.gamma = ispconfig["Gamma"];
        vzprof.ispprofile.denoise = ispconfig["Denoise"];
        vzprof.ispprofile.flipmode = ispconfig["Flip_Mode"];
        vzprof.ispprofile.effectmode = ispconfig["Effect_Mode"];
    } catch (std::exception &e) {
        logger->error("[%s][%d] LoadProfileSettingFromPath Fail!. %s", __FUNCTION__, __LINE__, e.what());

        std::cout << "[%s][%d] LoadProfileSettingFromPath Fail!. %s" <<  e.what() << std::endl;
        file.close();
        return -1;
    }

    file.close();

    return 0;
}

int VizionCam::SetProfileStreamingConfig(void)
{
    int ret = 0;
    std::vector<VzFormat> vzformatlist;

    VizionCam *vizion_cam ;
    if ((ret = GetCaptureFormatList(vzformatlist)) < 0) return ret;

    if (vzformatlist.size() <= 0) return -1;
    // Matching Format
    for (int i = 0; i < vzformatlist.size(); i++) {
        if (vzformatlist[i].width == vzprof.camprofile.width &&
                vzformatlist[i].height == vzprof.camprofile.height &&
                vzformatlist[i].framerate == vzprof.camprofile.framerate &&
                vzformatlist[i].format == vzprof.camprofile.format) {
            logger->trace("[%s][%d] Match the Streaming Profile Setting. [%d]W:%d H:%d FPS:%d Format:%s", __FUNCTION__, __LINE__
                          , i, vzformatlist[i].width, vzformatlist[i].height, vzformatlist[i].framerate, vzprof.camprofile.pixelformat_str.c_str());
            SetCaptureFormat(vzformatlist[i]);
            return 0;
        }
    }
    std::cout << "SetProfileStreamingConfig Fail  " << "W::" << vzprof.camprofile.width << "H::" << vzprof.camprofile.height << "FPS::" << vzprof.camprofile.framerate << "Format::" << vzprof.camprofile.pixelformat_str.c_str() << std::endl;
    logger->error("[%s][%d] SetProfileStreamingConfig Fail! Cannot Match the Streaming Profile Setting. W:%d H:%d FPS:%d Format:%s", __FUNCTION__, __LINE__
                  , vzprof.camprofile.width, vzprof.camprofile.height, vzprof.camprofile.framerate, vzprof.camprofile.pixelformat_str.c_str());
    return -1;
}

int VizionCam::SetProfileControlConfig(void)
{
    VizionCam *vizion_cam;
    try {
        if (vzprof.controlmode == "ISP") {
            std::cout << "++ISP++" << std::endl;
            SetAutoExposureMode(vzprof.ispprofile.ae_exp_mode ? AE_MODE_STATUS::AUTO_EXP : AE_MODE_STATUS::MANUAL_EXP);
            SetExposureTime(vzprof.ispprofile.ae_exp_time);
            SetExposureGain(vzprof.ispprofile.ae_ex_gain);
            SetBacklightCompensation(vzprof.ispprofile.brightness);

            SetAutoWhiteBalanceMode(vzprof.ispprofile.awb_mode ? AWB_MODE_STATUS::AUTO_WB : AWB_MODE_STATUS::MANUAL_TEMPERATURE_WB);
            SetTemperature(vzprof.ispprofile.awb_temp);

            SetGamma(vzprof.ispprofile.gamma);
            SetSaturation(vzprof.ispprofile.saturation);
            SetContrast(vzprof.ispprofile.contrast);
            SetSharpening(vzprof.ispprofile.sharpmess);
            SetDenoise(vzprof.ispprofile.denoise);

            SetFlipMode((FLIP_MODE)vzprof.ispprofile.flipmode);
            SetEffectMode((EFFECT_MODE)vzprof.ispprofile.effectmode);

            SetDigitalZoomTarget(vzprof.ispprofile.zoom_target);
            SetDigitalZoom_CT_X(vzprof.ispprofile.zoom_ctx);
            SetDigitalZoom_CT_Y(vzprof.ispprofile.zoom_cty);
        } else if (vzprof.controlmode == "UVC") {
            int flag = 0;
            std::cout << "++++UVC+++" << std::endl;
            SetPropertyValue(CAPTURE_BRIGHTNESS, vzprof.uvcprofile.brightness, flag);
            std::cout << "+++++++" << std::endl;
            SetPropertyValue(CAPTURE_CONTRAST, vzprof.uvcprofile.contrast, flag);
            SetPropertyValue(CAPTURE_EXPOSURE, vzprof.uvcprofile.exposure, vzprof.uvcprofile.exp_auto);
            SetPropertyValue(CAPTURE_GAIN, vzprof.uvcprofile.gain, flag);
            SetPropertyValue(CAPTURE_GAMMA, vzprof.uvcprofile.gamma, flag);
            SetPropertyValue(CAPTURE_PAN, vzprof.uvcprofile.pan, flag);
            SetPropertyValue(CAPTURE_TILT, vzprof.uvcprofile.tilt, flag);
            SetPropertyValue(CAPTURE_WHITEBALANCE, vzprof.uvcprofile.temperature, vzprof.uvcprofile.wb_auto);
            SetPropertyValue(CAPTURE_SATURATION, vzprof.uvcprofile.saturation, flag);
            SetPropertyValue(CAPTURE_SHARPNESS, vzprof.uvcprofile.sharpness, flag);
            SetPropertyValue(CAPTURE_ZOOM, vzprof.uvcprofile.zoom, flag);
        } else {
            logger->error("[%s][%d] SetProfileControlConfig Fail! Control Mode Fail. Mode:%s", __FUNCTION__, __LINE__, vzprof.controlmode.c_str());

            std::cout << "[%s][%d] SetProfileControlConfig Fail!. %s Control Mode Fail. Mode:%s" << std::endl;

            return -1;
        }
    } catch (std::exception &e) {
        logger->error("[%s][%d] SetProfileControlConfig Fail!. %s", __FUNCTION__, __LINE__, e.what());
        std::cout << "SetProfileControlConfig Fail!" << e.what() << std::endl;
        return -1;
    }

    return 0;
}


int VizionCam:: I2CHeaderReadname(int i2c_idx,uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t *data)
{
    int i2c_fd;
    char filename[20];
    uint8_t reg_addr_buf[2];
    struct i2c_rdwr_ioctl_data packets;
    struct i2c_msg messages[2];


    if (i2c_idx == -1) return -1;
    char i2c_name[32];

    sprintf(i2c_name, "/dev/i2c-%d", i2c_idx);

    // Open the I2C bus
    //sprintf(i2c_device, "/dev/i2c-1");
    if ((i2c_fd = open(i2c_name, O_RDWR)) < 0) {
        return -1;
    }

    // Set the slave address
    if (ioctl(i2c_fd, I2C_SLAVE_FORCE, slvaddr) < 0) {
        return -1;
    }
    // Write the register address
    if (reglen == 1) {
        reg_addr_buf[0] = (uint8_t)regaddr;
        if (write(i2c_fd, reg_addr_buf, 1) != 1) {
            close(i2c_fd);
            return -1;
        }
    } else if (reglen == 2) {
        reg_addr_buf[0] = regaddr >> 8;
        reg_addr_buf[1] = regaddr & 0xFF;
        for (int i = 0 ; i < 5; i++) {
            if (write(i2c_fd, reg_addr_buf, 2) != 2) {

                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                //close(i2c_fd);
                if(i==4){
                    return -1;
                  }

            } else {

                break;
            }
        }

    } else {
        printf("Failed to Write the register address.\n");
        return -1;
    }
    // Read the data
    for (int i = 0 ; i < 5; i++) {
        if (read(i2c_fd, data, datalen) != datalen) {


            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            //close(i2c_fd);
            if(i==4){
                return -1;
              }


        } else {
            break;
        }
    }



    // Close I2C bus
    close(i2c_fd);

    return 0;
}



int VizionCam:: LinuxI2CRead(uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t *data)
{
    int i2c_fd;
    char filename[20];
    uint8_t reg_addr_buf[2];
    struct i2c_rdwr_ioctl_data packets;
    struct i2c_msg messages[2];


    if (i2c_idx == -1) return -1;
    char i2c_name[32];

    sprintf(i2c_name, "/dev/i2c-%d", i2c_idx);

    // Open the I2C bus
    //sprintf(i2c_device, "/dev/i2c-1");
    if ((i2c_fd = open(i2c_name, O_RDWR)) < 0) {
        printf("Failed to open the bus.\n");
        return -1;
    }

    // Set the slave address
    if (ioctl(i2c_fd, I2C_SLAVE_FORCE, slvaddr) < 0) {
        printf("Failed to acquire bus access and/or talk to slave.\n");
        return -1;
    }
    // Write the register address
    if (reglen == 1) {
        reg_addr_buf[0] = (uint8_t)regaddr;
        if (write(i2c_fd, reg_addr_buf, 1) != 1) {
            std::cout << "Failed to write register address." << std::endl;
            close(i2c_fd);
            return -1;
        }
    } else if (reglen == 2) {
        reg_addr_buf[0] = regaddr >> 8;
        reg_addr_buf[1] = regaddr & 0xFF;
//        std::cout << "reg_addr_buf[0]: " << std::hex << static_cast<int>(reg_addr_buf[0]) << std::endl;
//        std::cout << "reg_addr_buf[1]: " << std::hex << static_cast<int>(reg_addr_buf[1]) << std::endl;
        for (int i = 0 ; i < 5; i++) {
            if (write(i2c_fd, reg_addr_buf, 2) != 2) {

                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                //close(i2c_fd);
                if(i==4){
                    std::cout << "Failed to write register address." << std::endl;
                    printf("%s\n", strerror(errno));
                  }

            } else {

                break;
            }
        }

    } else {
        printf("Failed to Write the register address.\n");
        return -1;
    }
    // Read the data
    for (int i = 0 ; i < 5; i++) {
        if (read(i2c_fd, data, datalen) != datalen) {


            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            //close(i2c_fd);
            if(i==4){
                std::cout << "Failed to read data." << std::endl;
                printf("%s\n", strerror(errno));
              }


        } else {
            break;
        }
    }
    // Print data

//    for (int i = 0; i < datalen; i++) {
//        std::cout << "Data: " << std::hex << static_cast<int>(data[i]) << " ";
//    }

    // Close I2C bus
    close(i2c_fd);

    return 0;
}


int VizionCam:: LinuxI2CWrite(uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t *data)
{
    int i2c_fd, res;
    char filename[20];
    uint8_t write_data[512];
    uint8_t reg_addr_buf[2];

    struct i2c_rdwr_ioctl_data packets;
    struct i2c_msg messages[1];
    //  const char* i2c_device = "/dev/i2c-1";
    //    if(selected_dev_idx==1){

    //        i2c_device="/dev/i2c-4";

    //      }

    if (i2c_idx == -1) return -1;
    char i2c_name[32];
    sprintf(i2c_name, "/dev/i2c-%d", i2c_idx);
//    std::cout << "/dev/i2c-" << i2c_idx << std::endl;

    // Open the I2C bus
    if ((i2c_fd = open(i2c_name, O_RDWR)) < 0) {
        printf("Failed to open the bus.\n");
        return -1;
    }

    // Set the slave address
    if (ioctl(i2c_fd, I2C_SLAVE_FORCE, slvaddr) < 0) {
        printf("Failed to acquire bus access and/or talk to slave.\n");
        return -1;
    }
    // Write the register address
    if (reglen == 1) {
        reg_addr_buf[0] = (uint8_t)regaddr;
        messages[0].len = 1;
        uint8_t write_data[2];
        write_data[0] = reg_addr_buf[0];

        for (int i = 0; i < datalen; i++) {

            write_data[i + 1] = data[i];
        }

        messages[0].addr = slvaddr;
        messages[0].flags = 0;
        messages[0].buf = reg_addr_buf;
    } else if (reglen == 2) {
        reg_addr_buf[0] = regaddr >> 8;
        reg_addr_buf[1] = regaddr & 0xFF;
        write_data[0] = reg_addr_buf[0];
        write_data[1] = reg_addr_buf[1];
        for (int i = 0; i < datalen; i++) {

            write_data[i + 2] = data[i];
        }

        messages[0].len = 2;
        messages[0].addr = slvaddr;
        messages[0].flags = 0;
        messages[0].buf = reg_addr_buf;
    } else {
        printf("Failed to Write the register address.\n");
        return -1;
    }

    packets.msgs = messages;
    packets.nmsgs = 1;

    for (int i = 0; i < 5; i++) {

      //  res = ioctl(i2c_fd, I2C_RDWR, &packets);
        if (ioctl(i2c_fd, I2C_RDWR, &packets) < 0) {

            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if(i==4){
                std::cout << ("Failed to write to the i2c bus.\n") << std::endl;
                printf("%s\n", strerror(errno));

              }

        } else {

            break;

        }

    }



    // Write the data
    for (int i = 0; i < 5; i++) {
        res = ioctl(i2c_fd, I2C_RDWR, &packets);
        if (write(i2c_fd, write_data, datalen + reglen) != datalen + reglen) {

            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if(i==4){
                std::cout << "Failed to write data." << std::endl;
                printf("%s\n", strerror(errno));
              }

        } else {

            break;

        }

    }

    // Close I2C bus
    close(i2c_fd);
//    std::cout << "Finish write data." << std::endl;
    return 0;
}

void error_handle_extension_unit()
{
    int res = errno;

    const char *err;
    switch (res) {
    case ENOENT:
        err = "Extension unit or control not found";
        break;
    case ENOBUFS:
        err = "Buffer size does not match control size";
        break;
    case EINVAL:
        err = "Invalid request code";
        break;
    case EBADRQC:
        err = "Request not supported by control";
        break;
    default:
        err = strerror(res);
        break;
    }

    printf("failed %s. (System code: %d) \n", err, res);

    return;
}

int write_to_UVC_extension(int fd, int property_id,
                           int length, unsigned char *buffer)
{
    struct uvc_xu_control_query xu_query;
    CLEAR(xu_query);
    xu_query.unit = 3;            //has to be unit 3
    xu_query.query = UVC_SET_CUR; //request code to send to the device
    xu_query.size = length;//4;
    xu_query.selector = property_id;//1;//
    xu_query.data = buffer; //control buffer

//    printf("AP1302 xu_query.size %x. \n", xu_query.size);
    if ((ioctl(fd, UVCIOC_CTRL_QUERY, &xu_query)) != 0) {
         printf("write_to_UVC_extension failed  xu_query.size %d.  \n", xu_query.size);

        error_handle_extension_unit();
        return -1;
    }
    return 0;
}


int read_from_UVC_extension(int fd, int property_id,
                            int length, unsigned char *buffer)
{
    struct uvc_xu_control_query xu_query;
    CLEAR(xu_query);
    xu_query.unit = 3;            //has to be unit 3
    xu_query.query = UVC_GET_CUR; //request code to send to the device
    xu_query.size = length;//4;
    xu_query.selector = property_id;//1;
    xu_query.data = buffer; //control buffer

    if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_query) != 0) {
        error_handle_extension_unit();
        return -1;
    }
    return 0;
}


int VizionCam::UVC_AP1302_I2C_Read(uint16_t addrReg, uint16_t &data)
{
    if (mipi_cam_flag == 1) {
        uint8_t data2[2];
        LinuxI2CRead(0x3d, 2, addrReg, 2, data2);

        data = ((uint16_t)data2[0] << 8) + ((uint16_t)data2[1] & 0xFF);
//        std::cout << "Mipi call UVC_AP1302_I2C_Read++++data :" << std::hex << static_cast<int>(data) << std::endl;
        return 0;
    } else {

        unsigned char AP1302_I2CMsg[LI_XU_SENSOR_REG_RW_SIZE] = {0};

        CLEAR(AP1302_I2CMsg);
        AP1302_I2CMsg[0] = SENSOR_REG_READ_FLG;
        AP1302_I2CMsg[1] = HIGHBYTE(addrReg);
        AP1302_I2CMsg[2] = LOWBYTE(addrReg);
        AP1302_I2CMsg[3] = 0;
        AP1302_I2CMsg[4] = 0;
        write_to_UVC_extension(
            this->fd,
            5,
            LI_XU_SENSOR_REG_RW_SIZE,
            AP1302_I2CMsg);

        AP1302_I2CMsg[0] = SENSOR_REG_READ_FLG;
        AP1302_I2CMsg[3] = 0;
        AP1302_I2CMsg[4] = 0;

        if (read_from_UVC_extension(
                    this->fd,
                    5,
                    LI_XU_SENSOR_REG_RW_SIZE,
                    AP1302_I2CMsg) != 0) {
            error_handle_extension_unit();
            return -1;
        }

        data = (AP1302_I2CMsg[3] << 8) + AP1302_I2CMsg[4];
//        printf("V4L2_CORE: Read Sensor REG[0x%x] = 0x%x\r\n", addrReg, data);

        return 0;

    }
}
int VizionCam::UVC_AP1302_I2C_Write(uint16_t addrReg, uint16_t data)
{
    if (mipi_cam_flag == 1) {
        uint8_t data2[2];
        data2[0] = data >> 8;
        data2[1] = data & 0xFF;
//        std::cout << "Mipi call UVC_AP1302_I2C_Write. " <<data<< std::endl;
        LinuxI2CWrite(0x3d, 2, addrReg, 2, data2);
        return 0;
    } else {

        unsigned char AP1302_I2CMsg[LI_XU_SENSOR_REG_RW_SIZE] = {0};
        CLEAR(AP1302_I2CMsg);

        AP1302_I2CMsg[0] = SENSOR_REG_WRITE_FLG;
        AP1302_I2CMsg[1] = HIGHBYTE(addrReg);
        AP1302_I2CMsg[2] = LOWBYTE(addrReg);
        AP1302_I2CMsg[3] = HIGHBYTE(data);
        AP1302_I2CMsg[4] = LOWBYTE(data);

        if (write_to_UVC_extension(this->fd, 5,
                                   LI_XU_SENSOR_REG_RW_SIZE, AP1302_I2CMsg) != 0) {
            error_handle_extension_unit();
            return -1;
        }

        return 0;

    }

}


/*
int VizionCam::UVC_AP1302_I2C_Read(uint16_t addrReg, uint16_t &data)
{
    if (mipi_cam_flag == 1) {
        uint8_t data2[2];
        LinuxI2CRead(0x3d, 2, addrReg, 2, data2);

        data = ((uint16_t)data2[0] << 8) + ((uint16_t)data2[1] & 0xFF);
        std::cout << "Mipi call UVC_AP1302_I2C_Read++++data :" << std::hex << static_cast<int>(data) << std::endl;
        return 0;
    } else {
        int ret = 0;
        unsigned char buf[EU5_TEST_CMD_LEN];
        static unsigned int read_data;
        CLEAR(buf);
        struct uvc_xu_control_query xu_ctrl_query_read =
        {
            .unit     = UVC_XU_ID,
            .selector = EU5_TEST_CMD,
            .query    = UVC_GET_CUR,
            .size     = EU5_TEST_CMD_LEN,
            .data     = NULL,
        };
        struct uvc_xu_control_query xu_ctrl_query_write =
        {
            .unit     = UVC_XU_ID,
            .selector = EU5_TEST_CMD,//
            .query    = UVC_SET_CUR,
            .size     = EU5_TEST_CMD_LEN,//
            .data     = NULL,
        };

            buf[0] = 1;  // Set Read Mode
            buf[1] = addrReg >> 8;
            buf[2] = addrReg & 0xFF;
            buf[3] = 0;
            buf[4] = 0;
            xu_ctrl_query_write.data = buf;
            xu_ctrl_query_read.data = buf;

            ret = ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write);
            if(ret < 0){
                printf("write query fail!\n");
                printf("%s\n",strerror(errno));
                error_handle_extension_unit();
                return ret;
            }
            ret = ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read);
            if(ret < 0){
                printf("read query fail!\n");
                printf("%s\n",strerror(errno));
                error_handle_extension_unit();
                return ret;
            }

            data = (unsigned int)((unsigned int)(buf[3] << 8) | (buf[4] & 0xFF));

            return ret;
      }
}
int VizionCam::UVC_AP1302_I2C_Write(uint16_t addrReg, uint16_t data)
{
    if (mipi_cam_flag == 1) {
        uint8_t data2[2];
        data2[0] = data >> 8;
        data2[1] = data & 0xFF;
        std::cout << "Mipi call UVC_AP1302_I2C_Write." << std::endl;
        LinuxI2CWrite(0x3d, 2, addrReg, 2, data2);
        return 0;
    } else {
        int ret = 0;
            unsigned char buf[EU5_TEST_CMD_LEN];
            CLEAR(buf);
            struct uvc_xu_control_query xu_ctrl_query_write =
            {
                .unit     = UVC_XU_ID,
                .selector = EU5_TEST_CMD,//
                .query    = UVC_SET_CUR,
                .size     = EU5_TEST_CMD_LEN,//
                .data     = NULL,
            };
            buf[0] = 0;  // Set Write Mode
            buf[1] = addrReg >> 8;
            buf[2] = addrReg & 0xFF;
            buf[3] = data >> 8;
            buf[4] = data & 0xFF;
            xu_ctrl_query_write.data = buf;


            ret = ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write);
            if(ret < 0){
                printf("write query fail!\n");
                printf("%s\n",strerror(errno));
                error_handle_extension_unit();
            }

            return ret;
        }
}

*/
int VizionCam::GenI2CRead(uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t *data)
{
    if (mipi_cam_flag == 1) {
        LinuxI2CRead(slvaddr, reglen, regaddr, datalen, data);

//        std::cout << "Mipi call Gen_I2C_Read++++data :" << std::hex << static_cast<int>(*data) << std::endl;
        return 0;
    } else {

        ULONG readCount;
        BYTE GenI2CRead[EU6_TEST_CMD_LEN] = {0};
        CLEAR(GenI2CRead);
        struct uvc_xu_control_query xu_ctrl_query_write = {
            .unit     = UVC_XU_ID,
            .selector = EU6_TEST_CMD,
            .query    = UVC_SET_CUR,
            .size     = EU6_TEST_CMD_LEN,
            .data     = NULL,
        };

        struct uvc_xu_control_query xu_ctrl_query_read = {
            .unit     = UVC_XU_ID,
            .selector = EU6_TEST_CMD,
            .query    = UVC_GET_CUR,
            .size     = EU6_TEST_CMD_LEN,
            .data     = NULL,
        };



        GenI2CRead[0] = (slvaddr << 1) | 1;
        GenI2CRead[1] = reglen;

        if ((reglen + datalen) > XU_I2C_CONTROL_MAX_DATA_LENS)
            return -1;

        if (reglen > XU_I2C_CONTROL_MAX_REG_ADDR_LENS)
            return -1;

        if (reglen == 1)
            GenI2CRead[3] = (uint8_t)regaddr;
        else if (reglen == 2) {
            GenI2CRead[2] = regaddr >> 8;
            GenI2CRead[3] = regaddr & 0xFF;
        } else {
            return -1;
        }
        GenI2CRead[2 + reglen] = datalen >> 8;
        GenI2CRead[3 + reglen] = datalen & 0xFF;

        xu_ctrl_query_write.data = GenI2CRead;
        xu_ctrl_query_read.data = GenI2CRead;

        if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write) != 0) {
            error_handle_extension_unit();
            return -1;
        }
        if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read) != 0) {
            error_handle_extension_unit();
            return -1;
        }

        memcpy(data, (uint8_t *)GenI2CRead + 4 + reglen, datalen);

//        std::cout << "UVC_Gen_XU_Read++++data HEX :" << std::hex << static_cast<int>(*data) << std::endl;

        return 0;
    }



}

int VizionCam::GenI2CWrite(uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint8_t datalen, uint8_t *data)
{
    if (mipi_cam_flag == 1) {
        LinuxI2CWrite(slvaddr, reglen, regaddr, datalen, data);

//        std::cout << "Mipi call Gen_I2C_Write++++data :" << std::hex << static_cast<int>(*data) << std::endl;
        return 0;
    } else {

        ULONG readCount;
        BYTE GenI2CWrite[XU_I2C_CONTROL_MAX_TRANS_LENS] = {0};
        CLEAR(GenI2CWrite);
        struct uvc_xu_control_query xu_ctrl_query_write = {
            .unit     = UVC_XU_ID,
            .selector = EU6_TEST_CMD,
            .query    = UVC_SET_CUR,
            .size     = EU6_TEST_CMD_LEN,
            .data     = NULL,
        };

        struct uvc_xu_control_query xu_ctrl_query_read = {
            .unit     = UVC_XU_ID,
            .selector = EU6_TEST_CMD,
            .query    = UVC_GET_CUR,
            .size     = EU6_TEST_CMD_LEN,
            .data     = NULL,
        };

        GenI2CWrite[0] = slvaddr << 1;
        GenI2CWrite[1] = reglen;

        if ((reglen + datalen) > XU_I2C_CONTROL_MAX_DATA_LENS)
            return -1;

        if (reglen == 1)
            GenI2CWrite[2] = (uint8_t)regaddr;
        else if (reglen == 2) {
            GenI2CWrite[2] = regaddr >> 8;
            GenI2CWrite[3] = regaddr & 0xFF;
        } else {
            return -1;
        }
        GenI2CWrite[2 + reglen] = datalen >> 8;
        GenI2CWrite[3 + reglen] = datalen & 0xFF;


        xu_ctrl_query_write.data = GenI2CWrite;

        memcpy((uint8_t *)(GenI2CWrite + 4 + reglen), data, datalen);

        if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write) != 0) {
            error_handle_extension_unit();
            return -1;
        }



//        int ret = ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write);
//        if (ret < 0) {
//            printf("write query fail!\n");
//            printf("%s\n", strerror(errno));
//        }

        // memcpy((uint8_t*)(GenI2CWrite + 4 + reglen), data, datalen);
//        std::cout << "UVC_Gen_XU_Write++++data HEX :" << std::hex << static_cast<int>(*data) << std::endl;
        return 0;
    }
}





int VizionCam::GetAutoExposureMode(AE_MODE_STATUS &ae_mode)
{
    int ret = 0;
    uint16_t aeaddr = 0x5002;
    uint16_t aectrl = 0x2090;
    //uint8_t aectrl[2] = {0x20, 0x90};

    aectrl |= (uint16_t)ae_mode;
    if (ret = UVC_AP1302_I2C_Read(aeaddr, aectrl) < 0)
        return ret;
    ae_mode = (AE_MODE_STATUS)(aectrl & 0x000F);
    return 0;
}
int VizionCam::SetAutoExposureMode(AE_MODE_STATUS ae_mode)
{
    uint16_t aeaddr = 0x5002;
    uint16_t aectrl = 0x2090;

    aectrl |= (uint16_t)ae_mode;

    return UVC_AP1302_I2C_Write(aeaddr, aectrl);
}
int VizionCam::GetCurrentExposureTime(uint32_t &exptime)
{
    int ret = 0;
    uint16_t exptimeaddr = 0x00E8;
    uint16_t exptime_lsb = 0, exptime_msb = 0;

    if (ret = UVC_AP1302_I2C_Read(exptimeaddr, exptime_msb) < 0) return ret;
    if (ret = UVC_AP1302_I2C_Read(exptimeaddr + 2, exptime_lsb) < 0) return ret;

    exptime = (exptime_msb << 16) + exptime_lsb;
    return 0;
}
int VizionCam::GetExposureTime(uint32_t &exptime)
{
    int ret = 0;
    uint16_t exptimeaddr = 0x500C;
    uint16_t exptime_lsb = 0, exptime_msb = 0;

    if (ret = UVC_AP1302_I2C_Read(exptimeaddr, exptime_msb) < 0) return ret;
    if (ret = UVC_AP1302_I2C_Read(exptimeaddr + 2, exptime_lsb) < 0) return ret;

    exptime = (exptime_msb << 16) + exptime_lsb;
    return 0;
}
int VizionCam::SetExposureTime(uint32_t exptime)
{
    uint16_t exptimeaddr = 0x500C;
    uint16_t exptime_lsb, exptime_msb;

    if (exptime > VZCAM_ISP_CONTROL_EXPOSURETIME_MAX || exptime < VZCAM_ISP_CONTROL_EXPOSURETIME_MIN) {
        printf("[%s][%d] Exposure Time range: %d ~ %d ms.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_EXPOSURETIME_MIN, VZCAM_ISP_CONTROL_EXPOSURETIME_MAX);
        return -1;
    }

    exptime_lsb = exptime & 0xFFFF;
    exptime_msb = (exptime >> 16) & 0xFFFF;
    UVC_AP1302_I2C_Write(exptimeaddr, exptime_msb);
    UVC_AP1302_I2C_Write(exptimeaddr + 2, exptime_lsb);

    return 0;
}
int VizionCam::GetCurrentExposureGain(uint8_t &expgain)
{
    uint16_t expgainaddr = 0x00F4;
    uint16_t expgain_val;
    UVC_AP1302_I2C_Read(expgainaddr, expgain_val);
    expgain = (expgain_val) & 0xFF;
    return  0;
}
int VizionCam::GetExposureGain(uint8_t &expgain)
{
    uint16_t expgainaddr = 0x5006;
    uint16_t expgain_val;
    UVC_AP1302_I2C_Read(expgainaddr, expgain_val);
    expgain = (expgain_val >> 8) & 0xFF;
    return  0;
}

int VizionCam::SetExposureGain(uint8_t expgain)
{
    if (expgain > VZCAM_ISP_CONTROL_GAIN_MAX || expgain < VZCAM_ISP_CONTROL_GAIN_MIN) {
        printf("[%s][%d] Exosure Gain Range: %d ~ %dx.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_GAIN_MIN, VZCAM_ISP_CONTROL_GAIN_MAX);
        return -1;
    }

    uint16_t expgainaddr = 0x5006;
    uint16_t expgain_val = (((uint16_t)expgain) << 8) & 0xFF00;
    return UVC_AP1302_I2C_Write(expgainaddr, expgain_val);
}
int VizionCam::GetMaxFPS(uint8_t &max_fps)
{
    uint16_t maxfpsaddr = 0x2020;
    uint16_t maxfps_val;
    UVC_AP1302_I2C_Read(maxfpsaddr, maxfps_val);
    max_fps = (maxfps_val >> 8) & 0xFF;
    return  0;
}

int VizionCam::SetMaxFPS(uint8_t max_fps)
{
    uint16_t maxfpsaddr = 0x2020;
    uint16_t maxfps_val = (((uint16_t)max_fps) << 8) & 0xFF00;
    return  UVC_AP1302_I2C_Write(maxfpsaddr, maxfps_val);
}

int VizionCam::GetAutoWhiteBalanceMode(AWB_MODE_STATUS &awb_mode)
{
    uint16_t awbaddr = 0x5100;
    uint16_t awbctrl = 0x1150;

    awbctrl |= (uint16_t)awb_mode;
    UVC_AP1302_I2C_Read(awbaddr, awbctrl);
    awb_mode = (AWB_MODE_STATUS)(awbctrl & 0x000F);
//    printf("awb_mode::%x",awb_mode);
    return 0;
}

int VizionCam::SetAutoWhiteBalanceMode(AWB_MODE_STATUS awb_mode)
{
    uint16_t awbaddr = 0x5100;
    uint16_t awbctrl = 0x1150;

    awbctrl |= (uint16_t)awb_mode;
    return UVC_AP1302_I2C_Write(awbaddr, awbctrl);
}

int VizionCam::GetTemperature(uint16_t &temp)
{
    uint16_t temp_addr = 0x510A;

    return UVC_AP1302_I2C_Read(temp_addr, temp);
}

int VizionCam::SetTemperature(uint16_t temp)
{
    uint16_t temp_addr = 0x510A;

    if (temp > VZCAM_ISP_CONTROL_TEMPERAURE_MAX || temp < VZCAM_ISP_CONTROL_TEMPERAURE_MIN) {
        printf("[%s][%d] Temperature Range: %d ~ %d K.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_TEMPERAURE_MIN, VZCAM_ISP_CONTROL_TEMPERAURE_MAX);
        return -1;
    }

    return UVC_AP1302_I2C_Write(temp_addr, temp);
}

int VizionCam::GetGamma(double &gamma)
{
    constexpr uint16_t gamma_addr = 0x700A;
    uint16_t gamma_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(gamma_addr, gamma_val) < 0) return -1;
    integer = (gamma_val >> 12) >= 8 ? (long)(gamma_val >> 12) - 16 : (long)(gamma_val >> 12);
    fractional = (double)(gamma_val & 0x0FFF) / 4096;
    gamma = integer + fractional;

    return 0;
}

int VizionCam::SetGamma(double gamma)
{
    if (gamma > VZCAM_ISP_CONTROL_GAMMA_MAX || gamma < VZCAM_ISP_CONTROL_GAMMA_MIN) {
        printf("[%s][%d] Saturation range: %01f ~ %01fx.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_GAMMA_MIN, VZCAM_ISP_CONTROL_GAMMA_MAX);
        return -1;
    }

    uint16_t gamma_addr = 0x700A;
    uint16_t gamma_val = 0;
    long integer = (gamma < 0) ? (long)gamma + 16 : (long)gamma;
    double fractional = (gamma < 0) ? (long)(integer - 16) - gamma : gamma - integer;
    gamma_val = gamma >= 0 ? (uint16_t)(integer << 12) + (uint16_t)(fractional * 4096) : (uint16_t)(integer << 12) - (uint16_t)(fractional * 4096);

    return UVC_AP1302_I2C_Write(gamma_addr, gamma_val);
}

int VizionCam::GetSaturation(double &saturation)
{
    constexpr uint16_t saturation_addr = 0x7006;
    uint16_t saturation_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(saturation_addr, saturation_val) < 0) return -1;
    integer = (saturation_val >> 12) >= 8 ? (long)(saturation_val >> 12) - 16 : (long)(saturation_val >> 12);
    fractional = (double)(saturation_val & 0x0FFF) / 4096;
    saturation = integer + fractional;

    return 0;
}

int VizionCam::SetSaturation(double saturation)
{
    if (saturation > VZCAM_ISP_CONTROL_SATURATION_MAX || saturation < VZCAM_ISP_CONTROL_SATURATION_MIN) {
        printf("[%s][%d] Saturation range: %01f ~ %01f.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_SATURATION_MIN, VZCAM_ISP_CONTROL_SATURATION_MAX);
        return -1;
    }

    uint16_t saturation_addr = 0x7006;
    uint16_t saturation_val = 0;
    long integer = (saturation < 0) ? (long)saturation + 16 : (long)saturation;
    double fractional = (saturation < 0) ? (long)(integer - 16) - saturation : saturation - integer;
    saturation_val = saturation >= 0 ? (uint16_t)(integer << 12) + (uint16_t)(fractional * 4096) : (uint16_t)(integer << 12) - (uint16_t)(fractional * 4096);

    return UVC_AP1302_I2C_Write(saturation_addr, saturation_val);
}

int VizionCam::GetContrast(double &contrast)
{
    constexpr uint16_t contrast_addr = 0x7002;
    uint16_t contrast_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(contrast_addr, contrast_val) < 0) return -1;
    integer = (contrast_val >> 12) >= 8 ? (long)(contrast_val >> 12) - 16 : (long)(contrast_val >> 12);
    fractional = (double)(contrast_val & 0x0FFF) / 4096;
    contrast = integer + fractional;

    return 0;
}

int VizionCam::SetContrast(double contrast)
{
    if (contrast > VZCAM_ISP_CONTROL_CONTRAST_MAX || contrast < VZCAM_ISP_CONTROL_CONTRAST_MIN) {
        printf("[%s][%d] Contrast range: %01f ~ %01f.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_CONTRAST_MIN, VZCAM_ISP_CONTROL_CONTRAST_MAX);
        return -1;
    }

    uint16_t contrast_addr = 0x7002;
    uint16_t contrast_val = 0;
    long integer = (contrast < 0) ? (long)contrast + 16 : (long)contrast;
    double fractional = (contrast < 0) ? (long)(integer - 16) - contrast : contrast - integer;
    contrast_val = contrast >= 0 ? (uint16_t)(integer << 12) + (uint16_t)(fractional * 4096) : (uint16_t)(integer << 12) - (uint16_t)(fractional * 4096);

    return UVC_AP1302_I2C_Write(contrast_addr, contrast_val);
}

int VizionCam::GetSharpening(double &sharpness)
{
    constexpr uint16_t sharpness_addr = 0x7010;
    uint16_t sharpness_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(sharpness_addr, sharpness_val) < 0) return -1;
    integer = (sharpness_val >> 12) >= 8 ? (long)(sharpness_val >> 12) - 16 : (long)(sharpness_val >> 12);
    fractional = (double)(sharpness_val & 0x0FFF) / 4096;
    sharpness = integer + fractional;

    return 0;
}

int VizionCam::SetSharpening(double sharpness)
{
    if (sharpness > VZCAM_ISP_CONTROL_SHARPENING_MAX || sharpness < VZCAM_ISP_CONTROL_SHARPENING_MIN) {
        printf("[%s][%d] Sharpening range: %01f ~ %01f.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_SHARPENING_MIN, VZCAM_ISP_CONTROL_SHARPENING_MAX);
        return -1;
    }

    uint16_t sharpness_addr = 0x7010;
    uint16_t sharpness_val = 0;
    long integer = (sharpness < 0) ? (long)sharpness + 16 : (long)sharpness;
    double fractional = (sharpness < 0) ? (long)(integer - 16) - sharpness : sharpness - integer;
    sharpness_val = sharpness >= 0 ? (uint16_t)(integer << 12) + (uint16_t)(fractional * 4096) : (uint16_t)(integer << 12) - (uint16_t)(fractional * 4096);

    return UVC_AP1302_I2C_Write(sharpness_addr, sharpness_val);
}

int VizionCam::GetDenoise(double &denoise)
{
    constexpr uint16_t denoise_addr = 0x700C;
    uint16_t denoise_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(denoise_addr, denoise_val) < 0) return -1;
    integer = (denoise_val >> 12) >= 8 ? (long)(denoise_val >> 12) - 16 : (long)(denoise_val >> 12);
    fractional = (double)(denoise_val & 0x0FFF) / 4096;
    denoise = integer + fractional;

    return 0;
}

int VizionCam::SetDenoise(double denoise)
{
    if (denoise > VZCAM_ISP_CONTROL_DENOISE_MAX || denoise < VZCAM_ISP_CONTROL_DENOISE_MIN) {
        printf("[%s][%d] Denoise range: %01f ~ %01f.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_DENOISE_MIN, VZCAM_ISP_CONTROL_DENOISE_MAX);
        return -1;
    }

    uint16_t denoise_addr = 0x700C;
    uint16_t denoise_val = 0;
    long integer = (denoise < 0) ? (long)denoise + 16 : (long)denoise;
    double fractional = (denoise < 0) ? (long)(integer - 16) - denoise : denoise - integer;
    denoise_val = denoise >= 0 ? (uint16_t)(integer << 12) + (uint16_t)(fractional * 4096) : (uint16_t)(integer << 12) - (uint16_t)(fractional * 4096);

    return UVC_AP1302_I2C_Write(denoise_addr, denoise_val);
}

int VizionCam::GetDigitalZoomType(DZ_MODE_STATUS &zoom_type)
{
    constexpr uint16_t zoomtype_addr = 0x1012;
    uint16_t zoomtype_val = 0;

    if (UVC_AP1302_I2C_Read(zoomtype_addr, zoomtype_val) < 0) return -1;

    zoom_type = (DZ_MODE_STATUS)zoomtype_val;

    return 0;
}
int VizionCam::SetDigitalZoomType(DZ_MODE_STATUS zoom_type)
{
    constexpr uint16_t zoomtype_addr = 0x1012;
    uint16_t zoomtype_val = (int)zoom_type;

    return UVC_AP1302_I2C_Write(zoomtype_addr, zoomtype_val);
}

int VizionCam::GetDigitalZoomTarget(double &times)
{
    constexpr uint16_t zoom_addr = 0x1010;
    uint16_t zoom_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(zoom_addr, zoom_val) < 0) return -1;
    integer = (zoom_val >> 8) & 0xFF;
    fractional = (double)(zoom_val & 0xFF) / 256;

    if (integer > 8 || integer < 1)
        return -1;

    times = integer + fractional;

    return 0;
}
int VizionCam::SetDigitalZoomTarget(double times)
{
    if (times > VZCAM_ISP_CONTROL_DIGITALZOOM_MAX || times < VZCAM_ISP_CONTROL_DIGITALZOOM_MIN) {
        printf("[%s][%d] Digital Zoom Range: %d ~ %dx.", __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_DIGITALZOOM_MIN, VZCAM_ISP_CONTROL_DIGITALZOOM_MAX);
        return -1;
    }

    constexpr uint16_t zoom_addr = 0x1010;
    uint16_t zoom_val = 0;
    long integer;
    double fractional;

    integer = (long)times;
    fractional = times - integer;

    zoom_val = (uint16_t)(integer << 8) + (uint16_t)(fractional * 256);

    return UVC_AP1302_I2C_Write(zoom_addr, zoom_val);
}
int VizionCam::GetDigitalZoom_CT_X(double &ct_x)
{
    constexpr uint16_t zoom_ctx_addr = 0x118C;
    uint16_t zoom_ctx_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(zoom_ctx_addr, zoom_ctx_val) < 0) return -1;
    integer = (zoom_ctx_val >> 8) & 0xFF;
    fractional = (double)(zoom_ctx_val & 0xFF) / 256;

    if (integer > 1 || integer < 0)
        return -1;

    ct_x = integer + fractional;

    return 0;
}
int VizionCam::SetDigitalZoom_CT_X(double ct_x)
{
    if (ct_x > VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MAX || ct_x < VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MIN) {
        printf("[%s][%d] Digital Zoom CT X: %.1f ~ %.1f.",
               __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MIN, VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MAX);
        return -1;
    }

    constexpr uint16_t zoom_ctx_addr = 0x118C;
    uint16_t zoom_ctx_val = 0;
    long integer;
    double fractional;

    integer = (long)ct_x;
    fractional = ct_x - integer;

    zoom_ctx_val = (uint16_t)(integer << 8) + (uint16_t)(fractional * 256);

    return UVC_AP1302_I2C_Write(zoom_ctx_addr, zoom_ctx_val);
}

int VizionCam::GetDigitalZoom_CT_Y(double &ct_y)
{
    constexpr uint16_t zoom_cty_addr = 0x118E;
    uint16_t zoom_cty_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(zoom_cty_addr, zoom_cty_val) < 0) return -1;
    integer = (zoom_cty_val >> 8) & 0xFF;
    fractional = (double)(zoom_cty_val & 0xFF) / 256;

    if (integer > 1 || integer < 0)
        return -1;

    ct_y = integer + fractional;

    return 0;
}
int VizionCam::SetDigitalZoom_CT_Y(double ct_y)
{
    if (ct_y > VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MAX || ct_y < VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MIN) {
        printf("[%s][%d] Digital Zoom CT Y: %.1f ~ %.1f.",
               __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MIN, VZCAM_ISP_CONTROL_DIGITALZOOM_CT_MAX);
        return -1;
    }

    constexpr uint16_t zoom_cty_addr = 0x118E;
    uint16_t zoom_cty_val = 0;
    long integer;
    double fractional;

    integer = (long)ct_y;
    fractional = ct_y - integer;

    zoom_cty_val = (uint16_t)(integer << 8) + (uint16_t)(fractional * 256);

    return UVC_AP1302_I2C_Write(zoom_cty_addr, zoom_cty_val);
}

int VizionCam::GetFlipMode(FLIP_MODE &flip)
{
    int ret = 0;
    uint16_t flipaddr = 0x100C;
    uint16_t flipctrl = 0x0000;

    if (ret = UVC_AP1302_I2C_Read(flipaddr, flipctrl) < 0)
        return ret;
    flip = (FLIP_MODE)(flipctrl & 0x3);

    return 0;
}

int VizionCam::SetFlipMode(FLIP_MODE flip)
{
    uint16_t flipaddr = 0x100C;
    uint16_t flipctrl = 0x0000;

    flipctrl = (uint16_t)flip;

    return UVC_AP1302_I2C_Write(flipaddr, flipctrl);
}

int VizionCam::GetEffectMode(EFFECT_MODE &effect)
{
    int ret = 0;
    uint16_t effectaddr = 0x1016;
    uint16_t effectctrl = 0x0000;

    if (ret = UVC_AP1302_I2C_Read(effectaddr, effectctrl) < 0)
        return ret;
    effect = (EFFECT_MODE)(effectctrl & 0xf);

    return 0;
}

int  VizionCam::SetEffectMode(EFFECT_MODE effect)
{
    uint16_t effectaddr = 0x1016;
    uint16_t effectctrl = 0x0000;

    effectctrl = (uint16_t)effect;

    return UVC_AP1302_I2C_Write(effectaddr, effectctrl);
}
int VizionCam::GetBacklightCompensation(double &ae_comp)
{
    constexpr uint16_t ae_comp_addr = 0x501A;
    uint16_t ae_comp_val = 0;
    long integer;
    double fractional;

    if (UVC_AP1302_I2C_Read(ae_comp_addr, ae_comp_val) < 0) return -1;
    integer = (ae_comp_val >> 8) > 15 ? (long)(ae_comp_val >> 8) - 0x100 : (long)(ae_comp_val >> 8);
    fractional = (double)(ae_comp_val & 0x00FF) / 256;

    if (integer > VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MAX || integer < VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MIN)
        return -1;

    ae_comp = integer + fractional;

    return 0;
}

int VizionCam::SetBacklightCompensation(double ae_comp)
{
    if (ae_comp > VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MAX || ae_comp < VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MIN) {
        printf("[%s][%d] Digital Zoom CT Y: %.1f ~ %.1f.",
               __FUNCTION__, __LINE__, VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MIN, VZCAM_ISP_CONTROL_BACKLIGHT_COMP_MAX);
        return -1;
    }

    constexpr uint16_t ae_comp_addr = 0x501A;
    uint16_t ae_comp_val = 0;
    long integer;
    double fractional;

    integer = (ae_comp < 0) ? (long)ae_comp + 256 : (long)ae_comp;
    fractional = (ae_comp < 0) ? (long)(integer - 256) - ae_comp : ae_comp - integer;

    ae_comp_val = ae_comp >= 0 ? (uint16_t)(integer << 8) + (uint16_t)(fractional * 256) : (uint16_t)(integer << 8) - (uint16_t)(fractional * 256);

    return UVC_AP1302_I2C_Write(ae_comp_addr, ae_comp_val);
}
int VizionCam::RecoverDefaultSetting()
{
    if (SetExposureTime(VZCAM_ISP_CONTROL_EXPOSURETIME_DEF)) return -1;
    if (SetExposureGain(VZCAM_ISP_CONTROL_GAIN_DEF)) return -1;
    if (SetBacklightCompensation(VZCAM_ISP_CONTROL_BACKLIGHT_COMP_DEF)) return -1;
    if (SetAutoExposureMode(AE_MODE_STATUS::AUTO_EXP)) return -1;
    if (SetTemperature(VZCAM_ISP_CONTROL_TEMPERAURE_DEF)) return -1;
    if (SetAutoWhiteBalanceMode(AWB_MODE_STATUS::AUTO_WB)) return -1;
    if (SetGamma(VZCAM_ISP_CONTROL_GAMMA_DEF)) return -1;
    if (SetSaturation(VZCAM_ISP_CONTROL_SATURATION_DEF)) return -1;
    if (SetContrast(VZCAM_ISP_CONTROL_CONTRAST_DEF)) return -1;
    if (SetSharpening(VZCAM_ISP_CONTROL_SHARPENING_DEF)) return -1;
    if (SetDenoise(VZCAM_ISP_CONTROL_DENOISE_DEF)) return -1;
    if (SetDigitalZoomTarget(VZCAM_ISP_CONTROL_DIGITALZOOM_DEF)) return -1;
    if (SetDigitalZoom_CT_X(VZCAM_ISP_CONTROL_DIGITALZOOM_CT_DEF)) return -1;
    if (SetDigitalZoom_CT_Y(VZCAM_ISP_CONTROL_DIGITALZOOM_CT_DEF)) return -1;
    if (SetDigitalZoomType(DZ_MODE_STATUS::DZ_IMMEDIATE)) return -1;
    if (SetEffectMode(EFFECT_MODE::NORMAL_MODE)) return -1;
    if (SetFlipMode(def_flip)) return -1;

    return 0;
}


int VizionCam::GetPropertyRange(CAPTURE_PROPETIES prop_id, long &min, long &max, long &step, long &def, long &caps)
{

    struct v4l2_queryctrl queryctrl;
    struct v4l2_control control;
    int prop = PropIdToV4L2Control(prop_id);
//    std::cout << prop_id << ":"  << std::endl;
//    std::cout << "GetPropertyRange fd:" << fd   << std::endl;
    queryctrl.id = prop;
    if (ioctl(fd, VIDIOC_QUERYCTRL, &queryctrl) == -1) {
        //close(fd);
        return -1;
    }

    if (!(queryctrl.flags & V4L2_CTRL_FLAG_DISABLED)) {
        control.id = prop;
        if (ioctl(fd, VIDIOC_G_CTRL, &control) == -1) {
            //close(fd);
            return -1;
        }

        min = queryctrl.minimum;
        max = queryctrl.maximum;
        step = queryctrl.step;
        def = queryctrl.default_value;
        caps = control.id & V4L2_CTRL_FLAG_UPDATE ? 1 : 0;

//        std::cout << "prop_id:" << prop_id << std::endl;
//        std::cout << "min" << min << std::endl;
//        std::cout << "max" << max << std::endl;
//        std::cout << "step" << step << std::endl;
//        std::cout << "def" << def << std::endl;
//        std::cout << "caps" << caps << std::endl;


    }
//    std::cout << "GetPropertyRange finish"  << std::endl;
    return 0;

}

int VizionCam::SetPropertyValue(CAPTURE_PROPETIES prop_id, long value, int flag)
{
    VizionCam *vizion_cam;
//    std::cout << "SetPropertyValue fd:" << fd   << std::endl;
    int control_id = PropIdToV4L2Control(prop_id);
    if (control_id == 0) {
        return -1;
    }

    struct v4l2_control control;
    memset(&control, 0, sizeof(control));

    switch (control_id) {
    case V4L2_CID_WHITE_BALANCE_TEMPERATURE:
        control.id = V4L2_CID_AUTO_WHITE_BALANCE;
        control.value = flag;
        if (ioctl(fd, VIDIOC_S_CTRL, &control) == -1) {
            perror("VIDIOC_S_CTRL");
            return -1;
        }
        if (flag == 1) return 0 ;
        break;

    case V4L2_CID_EXPOSURE_ABSOLUTE:
        control.id = V4L2_CID_EXPOSURE_AUTO;
        control.value = !flag;
        if (ioctl(fd, VIDIOC_S_CTRL, &control) == -1) {
            perror("VIDIOC_S_CTRL");
            return -1;
        }
        if (flag == 1) return 0 ;
        break;
    }

    control.id = control_id;
    control.value = value;
    if (ioctl(fd, VIDIOC_S_CTRL, &control) == -1) {
        perror("VIDIOC_S_CTRL");
        return -1;
    }




//    std::cout << prop_id << " VcSetPropertyValue:" << value << std::endl;
//    std::cout << "SetPropertyValue finish"  << std::endl;
    return 0;

}

int VizionCam::GetPropertyValue(CAPTURE_PROPETIES prop_id, long &value, int &flag)
{
    VizionCam *vizion_cam;
//    std::cout << "GetPropertyValue fd:" << fd   << std::endl;
    int prop = PropIdToV4L2Control(prop_id);

    struct v4l2_control control;
    control.id = prop;

    if (ioctl(fd, VIDIOC_G_CTRL, &control) == -1) {
        perror("VIDIOC_G_CTRL");
        return -1;
    }

    value = control.value;
    switch (control.id) {
    case V4L2_CID_WHITE_BALANCE_TEMPERATURE:
        control.id = V4L2_CID_AUTO_WHITE_BALANCE;
        if (ioctl(fd, VIDIOC_G_CTRL, &control) == -1) {
            perror("VIDIOC_G_CTRL");
            return -1;
        }
        flag = control.value;
        break;
    case V4L2_CID_EXPOSURE_ABSOLUTE:
        control.id = V4L2_CID_EXPOSURE_AUTO;
        if (ioctl(fd, VIDIOC_G_CTRL, &control) == -1) {
            perror("VIDIOC_G_CTRL");
            return -1;
        }
        flag = !control.value;
        break;
    default:
        flag = control.id == V4L2_CTRL_FLAG_UPDATE;
        break;
    }

//    std::cout << prop_id << " VcGetPropertyValue flag:" << flag << std::endl;
//    std::cout << prop_id << " VcGetPropertyValue:" << value << std::endl;
//    std::cout << "GetPropertyValue finish"  << std::endl;
    return 0;
}


int PropIdToV4L2Control(int prop_id)
{
    int control_id = 0;
    switch (prop_id) {
    case CAPTURE_BRIGHTNESS:
    default:
        control_id = V4L2_CID_BRIGHTNESS;
        break;
    case CAPTURE_CONTRAST:
        control_id = V4L2_CID_CONTRAST;
        break;
    case CAPTURE_HUE:
        control_id = V4L2_CID_HUE;
        break;
    case CAPTURE_SATURATION:
        control_id = V4L2_CID_SATURATION;
        break;
    case CAPTURE_SHARPNESS:
        control_id = V4L2_CID_SHARPNESS;
        break;
    case CAPTURE_GAMMA:
        control_id = V4L2_CID_GAMMA;
        break;
    case CAPTURE_COLORENABLE:
        control_id = V4L2_CID_COLORFX_CBCR;
        break;
    case CAPTURE_WHITEBALANCE:
        control_id = V4L2_CID_WHITE_BALANCE_TEMPERATURE;
        break;
    case CAPTURE_BACKLIGHTCOMPENSATION:
        control_id = V4L2_CID_BACKLIGHT_COMPENSATION;
        break;
    case CAPTURE_GAIN:
        control_id = V4L2_CID_GAIN;
        break;
    case CAPTURE_PAN:
        control_id = V4L2_CID_PAN_ABSOLUTE;
        break;
    case CAPTURE_TILT:
        control_id = V4L2_CID_TILT_ABSOLUTE;
        break;
    case CAPTURE_ROLL:
        control_id = V4L2_CID_ROTATE;
        break;
    case CAPTURE_ZOOM:
        control_id = V4L2_CID_ZOOM_ABSOLUTE;
        break;
    case CAPTURE_EXPOSURE:
        control_id = V4L2_CID_EXPOSURE_ABSOLUTE;
        break;
    case CAPTURE_IRIS:
        control_id = V4L2_CID_IRIS_ABSOLUTE;
        break;
    case CAPTURE_FOCUS:
        control_id = V4L2_CID_FOCUS_ABSOLUTE;
        break;
    }
    return control_id;
}


int VizionCam::GetBootdataHeader(VzHeader *header)
{
    VzHeader *temp_header;
    int header_size = sizeof(struct VzHeader);
   if (header == nullptr)
       return -1;

    temp_header = new VzHeader();
    GenI2CRead(0x54, 2, (uint16_t)0x0000, header_size, (uint8_t *)(temp_header));


    memcpy(header, temp_header, header_size);

    //std::cout << "temp_header->product_name::" << temp_header->product_name << std::endl;

    if (temp_header != nullptr) {
        delete temp_header;
        temp_header = nullptr;
    }

    return 0;
}


int VizionCam::GetBootdataHeaderV3(VzHeaderV3 *header)
{
    VzHeaderV3 *temp_header;
    int header_size = sizeof(struct VzHeaderV3);
//    std::cout << "header_size::" << header_size << std::endl;
    if (header == nullptr) {
        return -1;
    }

    temp_header = new VzHeaderV3();
    GenI2CRead(0x54, 2, (uint16_t)0x0000, header_size, (uint8_t *)(temp_header));
    memcpy(header, temp_header, header_size);
    if (temp_header != nullptr) {
        delete temp_header;
        temp_header = nullptr;
    }
    return 0;
}
int VizionCam::CheckHeaderVer()
{


    if (GenI2CRead(0x54, 2, 0x0000, 1, &header_ver) < 0) {
        return -1;
    }

//    std::cout << "header_ver::" << std::hex << static_cast<int>(header_ver) << std::endl;

    return header_ver;
}

int VizionCam::GetDeviceHardwareID(wchar_t *hardware_id)
{

    if (mipi_cam_flag == 1) {

        hardware_id = L"";
//        std::wcout << "HID::" << hardware_id << std::endl;
        return  -1;
    }

    std::string str_num = std::to_string(dev_idx);
    std::string cmd = "cat /sys/class/video4linux/video" + str_num + "/device/uevent | grep 'PRODUCT'";
//    std::cout << "cmd ::" << cmd << std::endl;
    std::string product_info = {""};
    FILE *fp = popen(cmd.c_str(), "r");
    if (fp == nullptr) {
        std::cout << "cmd error" << std::endl;
        logger->error("VcGGetDeviceHardwareID cmd error\n: {}  ", strerror(errno));
        return -1;
    }

    std::stringstream ss;
    char buffer[1024];
    while (fgets(buffer, 1024, fp)) {
        ss << buffer;
    }

    std::string str = ss.str();
    std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;

    std::wstring hardwareid;
    size_t pos = str.find("=");
    if (pos != std::string::npos) {
        str = str.substr(pos + 1);
    }
    std::stringstream ss2(str);
    std::string token;

    int counter = 0;
    while (std::getline(ss2, token, '/')) {
        if (counter > 1) {
            break;
        } else if (counter == 0) {
            vendor_id=std::stoi(token);
            hardwareid += L"vid_";


        } else if (counter == 1) {
            product_id=std::stoi(token);
            hardwareid += L"&pid_";


        }
        if (token.length() == 3) {
            // Insert 0's at the beginning of the token to make it 4 digits
            hardwareid += L"0";
        } else if (token.length() == 2) {
            // Insert 0's at the beginning of the token to make it 4 digits
            hardwareid += L"00";
        }

        hardwareid += std::to_wstring(std::stoi(token));
        counter++;
    }

    wcsncpy(hardware_id, hardwareid.c_str(), hardwareid.length() + 1);
//    std::wcout << "HID::" << hardware_id << std::endl;
    return 0;
}


int VizionCam::GotoProgramMode()
{

  ULONG readCount;
  BYTE tmpString[1] = {1};


  struct uvc_xu_control_query xu_ctrl_query_write = {
      .unit     = UVC_XU_ID,
      .selector = 2,//EU1_TEST_CMD,
      .query    = UVC_SET_CUR,
      .size     = 1,//EU1_TEST_CMD_LEN,
      .data     = NULL,
  };

  struct uvc_xu_control_query xu_ctrl_query_read = {
      .unit     = UVC_XU_ID,
      .selector = 2,//EU1_TEST_CMD,
      .query    = UVC_GET_CUR,
      .size     = 1,//EU1_TEST_CMD_LEN,
      .data     = NULL,
  };


  xu_ctrl_query_write.data = tmpString;
  xu_ctrl_query_read.data = tmpString;



  if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_write) < 0) {
      printf("write query fail!\n");
      printf("%s\n", strerror(errno));
      error_handle_extension_unit();
      return -1;
  }
//   ret = ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read);
//  if (ret < 0) {
//      printf("read query fail!\n");
//      printf("%s\n", strerror(errno));
//      error_handle_extension_unit();
//      return ret;
//  }


//  std::cout << "GotoProgramMode:" << std::hex << static_cast<int>(*tmpString) << std::endl;

  return 0;
}

int VizionCam::ClearISPBootdata(void)
{
    uint8_t wt_size = 128;
    uint8_t slvaddr = 0x54;
    uint8_t wtbuf[128];
    uint32_t cur_reg = 0;

    for (int i = 0; i < 128; i++)
        wtbuf[i] = 0xFF;

    //Clear EEPROM (0x54)0x0000-0xFFFF, (0x55)0x0000-0xFFFF
    // Clear Slave ID 0x54
    while (1) {
        GenI2CWrite(0x54, 2, (uint16_t)cur_reg, 128, (uint8_t *)wtbuf);
        cur_reg += 128;
        if (cur_reg > 0xFFFF)
            break;
    }
    // Clear Slave ID 0x55
    while (1) {
        GenI2CWrite(0x55, 2, (uint16_t)(cur_reg & 0xFFFF), 128, (uint8_t *)wtbuf);
        cur_reg += 128;
        if (cur_reg > 0x1FFFF)
            break;
    }
    return 0;
}

int VizionCam::DownloadBootdata(const char* binfilepath)
{
  printf("----------start---------------------------\n");
	std::ifstream input(binfilepath, std::ios::binary);
	// copies all data into buffer
	std::vector<uint8_t> buffer(std::istreambuf_iterator<char>(input), {});
	int ret = 0;
	int count = 0;
	int remain = 0;
	char fuse_id_str[64] = {0};
	uint16_t fix_checksum = 0;
	uint16_t total_checksum = 0;

	remain = buffer.size() % 16;

#ifdef _DEBUG
	printf("Bootdata  : 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
	printf("----------------------------------------------------------\n");
	for (int j = 0; j < buffer.size(); j += 16) {
		count++;
		printf("0x%08x:", j);
		for (int i = 0; i < 16; i++) {
			printf(" %02x", (uint8_t)(buffer.data() + i + j));
		}
		printf("\n");
	}
	if (remain > 0) {
		printf("0x%08x:", count * 16);
		for (int i = 0; i < remain; i++) {
			printf(" %02x", (uint8_t)(buffer.data() + i + count * 16));
		}
		printf("\n");
	}
#endif
	for (int j = 0; j < buffer.size(); j += 128) {
		if (j < 0xFFFF)
			GenI2CWrite(0x54, 2, (uint16_t)j, 128, (uint8_t*)(buffer.data() + count * 128));
		else
			GenI2CWrite(0x55, 2, (uint16_t)(j & 0xFFFF), 128, (uint8_t*)(buffer.data() + count * 128));
		count++;
	}
	if (remain > 0) {
		GenI2CWrite(0x55, 2, (uint16_t)(count * 128 & 0xFFFF), remain, (uint8_t*)(buffer.data() + count * 128));
		//printf("\n");
	}

#ifdef _DEBUG
	uint8_t readdata[16];
	printf("Bootdata  : 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
	printf("----------------------------------------------------------\n");
	for (int j = 0; j < buffer.size(); j += 16) {
		if (j < 0xFFFF)
			GenI2CRead(0x54, 2, (uint16_t)j, 16, (uint8_t*)readdata);
		else
			GenI2CRead(0x55, 2, (uint16_t)(j & 0xFFFF), 16, (uint8_t*)readdata);
		printf("0x%08x:", j);
		for (int i = 0; i < 16; i++) {
			printf(" %02x", readdata[i]);
		}
		printf("\n");
		count++;
	}
	if (remain > 0) {
		GenI2CRead(0x55, 2, (uint16_t)((count * 16) & 0xFFFF), remain, (uint8_t*)readdata);
		printf("0x%08x:", count * 16);
		for (int i = 0; i < remain; i++) {
			printf(" %02x", readdata[i]);
		}
		printf("\n");
	}
#endif

	// Check Bootdata
	std::this_thread::sleep_for(std::chrono::milliseconds(100));
	int a =CheckHeaderVer();
	if (CheckHeaderVer() == 3) {
		VzHeaderV3 v3;		
	       GetBootdataHeaderV3(&v3);

		uint8_t headerbytes[123];
		uint32_t sum = 0;
//		printf("----------------GetUniqueSensorID-----------------------\n");
		if ((ret = GetUniqueSensorID(fuse_id_str)) < 0) {
			logger->error("[%s][%d] Get Unique Sensor ID Fail!", __FUNCTION__, __LINE__);
			printf("Get Unique Sensor ID Fail\n" , fuse_id_str);
			return ret;
		}
		printf("Get Unique Sensor ID: %s\n" , fuse_id_str);
		logger->debug("[%s][%d] Get Unique Sensor ID: %s", __FUNCTION__, __LINE__, fuse_id_str);

		for (int i = 0; i < 8; i++) {
			this->fuse_id[i] = bswap_16(this->fuse_id[i]);
			GenI2CWrite(0x54, 2, 0x0005 + i * 2, 2, (uint8_t*)(this->fuse_id + i));
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
		//Sleep(10);

		if ((ret = GetBootdataHeaderV3(&v3)) < 0) {
			logger->error("[%s][%d] GetBootdataHeaderV3 Fail!", __FUNCTION__, __LINE__);
			return ret;
		}
//		printf(" Get Header Fuse ID: %02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X\n",
//		       , v3.sensor_fuseid[0], v3.sensor_fuseid[1], v3.sensor_fuseid[2], v3.sensor_fuseid[3]
//		       , v3.sensor_fuseid[4], v3.sensor_fuseid[5], v3.sensor_fuseid[6], v3.sensor_fuseid[7]
//		       , v3.sensor_fuseid[8], v3.sensor_fuseid[9], v3.sensor_fuseid[10], v3.sensor_fuseid[11]
//		       , v3.sensor_fuseid[12], v3.sensor_fuseid[13], v3.sensor_fuseid[14], v3.sensor_fuseid[15]);
		logger->debug("[%s][%d] Get Header Fuse ID: %02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X", __FUNCTION__, __LINE__
			, v3.sensor_fuseid[0], v3.sensor_fuseid[1], v3.sensor_fuseid[2], v3.sensor_fuseid[3]
			, v3.sensor_fuseid[4], v3.sensor_fuseid[5], v3.sensor_fuseid[6], v3.sensor_fuseid[7]
			, v3.sensor_fuseid[8], v3.sensor_fuseid[9], v3.sensor_fuseid[10], v3.sensor_fuseid[11]
			, v3.sensor_fuseid[12], v3.sensor_fuseid[13], v3.sensor_fuseid[14], v3.sensor_fuseid[15]);

		// Calculate Checksum
		logger->debug("[%s][%d] Calculate CheckSum of Fixed Section...", __FUNCTION__, __LINE__);
		GenI2CRead(0x54, 2, 0x0000, 123, (uint8_t*)headerbytes);
		for (int i = 0; i < 101; i++) {
		    sum += headerbytes[i];
//		std::cout << "headerbytes i="<<std::dec<<i <<"byte::"<< std::hex << static_cast<int>(headerbytes[i]) << std::endl;
		  }
		fix_checksum = sum % 0xFFFF;
		headerbytes[101] = (uint8_t)(fix_checksum & 0xFF);
		headerbytes[102] = (uint8_t)((fix_checksum >> 8) & 0xFF);
		for (int i = 101; i < 123; i++) {
		    sum += headerbytes[i];
//		    std::cout << "headerbytes i="<<std::dec<<i  <<"byte::"<< std::hex << static_cast<int>(headerbytes[i]) << std::endl;
		  }
		total_checksum = sum % 0xFFFF;

		//GenI2CWrite(0x54, 2, 0x0065, 2, temp);
		GenI2CWrite(0x54, 2, 0x0065, 2, (uint8_t*)(&fix_checksum));
		logger->debug("[%s][%d] Fixed Checksum: 0x%04X", __FUNCTION__, __LINE__, fix_checksum);
		std::cout << "fix_checksum hex::" << std::hex << static_cast<int>(fix_checksum) << std::endl;
//		printf("Fixed Checksum: 0x%04X \n", fix_checksum);
		GenI2CWrite(0x54, 2, 0x007B, 2, (uint8_t*)(&total_checksum));
		logger->debug("[%s][%d] Total Checksum: 0x%04X", __FUNCTION__, __LINE__, total_checksum);
//		printf(" Total Checksum: 0x%04X \n", total_checksum);
		std::cout << "total_checksum hex::" << std::hex << static_cast<int>(total_checksum) << std::endl;
	}

	logger->debug("[%s][%d] DownloadBootdata Completed.", __FUNCTION__, __LINE__);
//	printf("------------------------DownloadBootdata---finish-------------------------------\n");
	return 0;
}



void VizionCam::GetDeviceSpeed(USB_DEVICE_SPEED &usb_speed)
{

  if(mipi_cam_flag==1){

//      std::cout << "mipi_cam" << std::endl;
    }else{


    std::string cmd = "udevadm info -a -n /dev/video"+std::to_string(dev_idx)+" |grep '{speed}'";
  std::string usb_info = {""};
  std::string usbspeed={""};
  FILE *fp = popen(cmd.c_str(), "r");
  if (fp == nullptr) {
      std::cout << "cmd error" << std::endl;
      logger->error("GetDeviceSpeed cmd error\n: {}  ", strerror(errno));
   //   return -1;
  }


  char *buf3 = nullptr;
  size_t bufsize = 0;
  std::string first_line;

  if (getline(&buf3, &bufsize, fp) != -1) {
      first_line = buf3;
  }
      //std::string line(buf3);

      std::size_t pos = first_line.find("speed");
      if (pos != std::string::npos ) {
          usb_info = first_line.substr(pos + 8, 8);
//          std::cout << "usb_info::" << usb_info << std::endl;
        }
      for (char c : usb_info) {
              if ((c >= '0' && c <= '9') ) {
                  usbspeed += c;
              }
          }
          //logger->info("product_info[0] : {}" ,product_info[0]);


  free(buf3);
  pclose(fp);

//  std::cout << "usbspeed::" << usbspeed << std::endl;

       int speed;

        try {
            speed = std::stoi(usbspeed);
        } catch (...) {
            std::cout << "Failed to convert speed to int" << std::endl;

        }

        switch (speed) {
            case 10000:
                usb_speed=SuperSpeedPlus;
                break;
               // return SuperSpeedPlus;
            case 5000:
                  usb_speed=UsbSuperSpeed;
                  break;
              //  return UsbSuperSpeed;
            case 480:
                usb_speed=UsbHighSpeed;
                break;
               // return UsbHighSpeed;
            case 12:
                usb_speed=UsbFullSpeed;
                break;
                //return UsbFullSpeed;
            case 1:
                usb_speed=UsbLowSpeed;
                break;
                //return UsbLowSpeed;
        }
        //pclose(fp2);


//    std::cout << "Device speed: " << usb_speed << std::endl;
    }


}




int VizionCam:: GetVizionCamDeviceName(wchar_t *devname)
{


    if (dev_name.size() == 0) {
//        std::cout << "devname empty" << std::endl;
        return -1;
    }

    swprintf(devname, dev_name.size() + 1, L"%ls", dev_name.c_str());
    return 0;
}

int VizionCam::GetUniqueSensorID(char *sensor_id)
{
    uint16_t data = 0;
    uint16_t count = 0;
    // Check Sensor Normal ID
    std::vector<uint8_t> sid_list = { 0x20, 0x6c, 0x6e };
    uint8_t sid = 0x00;
    uint16_t fuse_id_addr = 0x3800;

   // uint16_t fuse_id[8];
//    if (mipi_cam_flag == 1) {
//        //mipi_cam do not get UID
//        return -1;
//    }
    VzHeaderV3 v3;
    if (CheckHeaderVer() == 3)
            {
                    GetBootdataHeaderV3(&v3);
//                    std::cout << "v3.fix_checksum hex::" << std::hex << static_cast<int>(v3.fix_checksum) << std::endl;
                    if (v3.fix_checksum != 0xFFFF) {
                            snprintf(sensor_id, 64, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X"
                                    , v3.sensor_fuseid[0], v3.sensor_fuseid[1], v3.sensor_fuseid[2], v3.sensor_fuseid[3]
                                    , v3.sensor_fuseid[4], v3.sensor_fuseid[5], v3.sensor_fuseid[6], v3.sensor_fuseid[7]
                                    , v3.sensor_fuseid[8], v3.sensor_fuseid[9], v3.sensor_fuseid[10], v3.sensor_fuseid[11]
                                    , v3.sensor_fuseid[12], v3.sensor_fuseid[13], v3.sensor_fuseid[14], v3.sensor_fuseid[15]);
                            std::cout << "V3sensor_id: " << sensor_id << std::endl;
                            logger->debug("[%s][%d] Get Header V3 Fuse ID: %s", __FUNCTION__, __LINE__, sensor_id);
                            return 0;
                    }
      }else{

        std::cout << "Header please updata to V3" << std::endl;
        logger->debug("Header please updata to V3");
        return -1;
      }

    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    std::cout << "sleep_for:2000 "  << std::endl;

    while (++count < 50) {

        if (count >= 50) {
            logger->error("[%s][%d] Check ISP ID Fail!", __FUNCTION__, __LINE__);

            return -1;
        }
        if (UVC_AP1302_I2C_Read(0x0000, data) == 0) {
            logger->debug("[%s][%d] Check ISP ID Success! ISP ID: 0x%04X", __FUNCTION__, __LINE__, data);
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }

    BYTE fw_ver[4];
    GetUSBFirmwareVersion(fw_ver);

    UVC_AP1302_I2C_Read(0x601A, data);
    if (((fw_ver[0] >= 23) && (fw_ver[1] >= 3) && (fw_ver[2] >= 3) && (fw_ver[3] >= 8)) &&
            (data & 0x200) == 0x200) {

        //check header V3
        // Wakup Sensor
        count = 0;
        data = 0;
        uint16_t temp = 0x380;
        UVC_AP1302_I2C_Write(0x601A, temp);

        while (count < 10) {
            if (++count >= 10) {
                logger->error("[%s][%d] Wake Sensor Up Fail! retry count = %d, Status=0x%04X", __FUNCTION__, __LINE__, count, data);
                break;
            }
            UVC_AP1302_I2C_Read(0x601A, data);
            if ((data & 0x200) == 0) {
                logger->debug("[%s][%d] Wake Sensor Up Success! retry count = %d, Status=0x%04X", __FUNCTION__, __LINE__, count, data);
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
//     std::cout << "2222222222222222222222"  << std::endl;
//    else {
//        //Header v2

//        std::cout << "+++++++++++++++++V2++++++++++++++++:" << std::endl;
//        return  -1;
//    }

    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    for (int i = 0; i < sid_list.size(); i++) {
        if (AdvReadSensorRegister(sid_list[i], 0x3000, data) == 0) {          
            if (data != 0) {
                logger->debug("[%s][%d] AdvReadSensorRegister Success. Sensor ID=0x%04x", __FUNCTION__, __LINE__, data);


                sid = sid_list[i];
                break;
            }
        }
    }
     std::cout << "sid::"<<sid  << std::endl;
    if (sid == 0) {
        logger->error("[%s][%d] Check Sensor SID Fail!", __FUNCTION__, __LINE__);
        return -1;
    }
    if (data == 0x2557 || data == 0x0F56) // if SID is AR0821(0x2557) or AR0822(0x0F56)
        fuse_id_addr = 0x34C0;
    AdvWriteSensorRegister(sid, 0x304C, 0x0100);
    AdvWriteSensorRegister(sid, 0x304A, 0x0210);


    std::this_thread::sleep_for(std::chrono::milliseconds(50));

//    for (int i = 0; i < 8; i++) {
//        if (AdvReadSensorRegister(sid, fuse_id_addr + i * 2, fuse_id[i]) == 0) {
//            logger->debug("[%s][%d] AdvReadSensorRegister Success. FuseID[%d]=0x%04x", __FUNCTION__, __LINE__, i, fuse_id[i]);
//        } else {
//            logger->error("[%s][%d] AdvReadSensorRegister Fail! Read FuseID[%d] Fail", __FUNCTION__, __LINE__, i);
//            return -1;
//        }
//    }

//    snprintf(sensor_id, 64, "%04X%04X%04X%04X%04X%04X%04X%04X"
//             , fuse_id[7], fuse_id[6], fuse_id[5], fuse_id[4]
//             , fuse_id[3], fuse_id[2], fuse_id[1], fuse_id[0]);
    for (int i = 0; i < 8; i++) {
            if (AdvReadSensorRegister(sid, fuse_id_addr + i * 2, fuse_id[7 - i]) == 0) {
                    logger->debug("[%s][%d] AdvReadSensorRegister Success. FuseID[%d]=0x%04x", __FUNCTION__, __LINE__, i, fuse_id[7 - i]);
            }
            else {
                    logger->error("[%s][%d] AdvReadSensorRegister Fail! Read FuseID[%d] Fail", __FUNCTION__, __LINE__, i);
                    return -1;
            }
    }

    snprintf(sensor_id, 64, "%04X%04X%04X%04X%04X%04X%04X%04X"
            , fuse_id[0], fuse_id[1], fuse_id[2], fuse_id[3]
            , fuse_id[4], fuse_id[5], fuse_id[6], fuse_id[7]);
    std::cout << "sensor_id: " << sensor_id << std::endl;

    logger->debug("[%s][%d] GetUniqueSensorID Success! Sensor UID = %s", __FUNCTION__, __LINE__, sensor_id);
    return 0;
}

int VizionCam::AdvWriteSensorRegister(uint16_t sen_sid, uint16_t sen_addrReg, uint16_t sen_data)
{
    int count = 0;
    uint16_t temp_data = 0x0000;

    while (count < 20) {
        if (++count >= 20) {
            logger->error("[%s][%d] I2C BUS 1 Check Fail!", __FUNCTION__, __LINE__);
            return -1;
        }
        UVC_AP1302_I2C_Read(0x60AC, temp_data);
        if ((temp_data & 0x7) == 0)
            break;
    }

    // Start to set SMIP Parameter
    UVC_AP1302_I2C_Write(0x60A8, 0x0000);
    UVC_AP1302_I2C_Write(0x60AA, 0x0002);

    UVC_AP1302_I2C_Write(0x60A0, 0x0000);
    UVC_AP1302_I2C_Write(0x60A2, sen_data);
    UVC_AP1302_I2C_Write(0x60A4, 0xF300 | sen_sid);
    UVC_AP1302_I2C_Write(0x60A6, sen_addrReg);

    UVC_AP1302_I2C_Write(0x60AC, 0x0301);

    count = 0;

    while (count < 20) {
        if (++count >= 20) {
            logger->error("[%s][%d] Check Status Fail!", __FUNCTION__, __LINE__);
            return -1;
        }
        UVC_AP1302_I2C_Read(0x60AC, temp_data);
        if ((temp_data & 0x7) == 0)
            break;
    }

    logger->debug("[%s][%d] AdvWriteSensorRegister Success. Sensor Reg=0x%04x, Data=0x%04x", __FUNCTION__, __LINE__, sen_addrReg, sen_data);
    return 0;
}

int VizionCam::AdvReadSensorRegister(uint16_t sen_sid, uint16_t sen_addrReg, uint16_t &sen_data)
{
    int count = 0;
    uint16_t temp_data = 0x0000;

    //if (UVC_AP1302_I2C_Read(0x0000, temp_data) != 0) {
    //    vzlog->Error("[%s][%d] Check ISP ID Fail!", __FUNCTION__, __LINE__);
    //    return -1;
    //}
    //else
    //    vzlog->Debug("[%s][%d] ISP IS WORKING! ISP_ID:0x%04X", __FUNCTION__, __LINE__, temp_data);
    //
    //count = 0;
    while (count < 20) {
        if (++count >= 20) {
            logger->error("[%s][%d] I2C BUS 1 Check Fail!", __FUNCTION__, __LINE__);
            return -1;
        }
        UVC_AP1302_I2C_Read(0x60AC, temp_data);
        if ((temp_data & 0x7) == 0)
            break;
    }

    // Start to set SMIP Parameter
    UVC_AP1302_I2C_Write(0x60A8, 0x0000);
    UVC_AP1302_I2C_Write(0x60AA, 0x0002);

    UVC_AP1302_I2C_Write(0x60A0, 0x0300 | sen_sid);
    UVC_AP1302_I2C_Write(0x60A2, sen_addrReg);
    UVC_AP1302_I2C_Write(0x60A4, 0x0000);
    UVC_AP1302_I2C_Write(0x60A6, 0x60A4);

    UVC_AP1302_I2C_Write(0x60AC, 0x6032);

    count = 0;

    while (count < 20) {
        if (++count >= 20) {
            logger->error("[%s][%d] Check Status Fail!", __FUNCTION__, __LINE__);
            return -1;
        }
        UVC_AP1302_I2C_Read(0x60AC, temp_data);
        if ((temp_data & 0x7) == 0)
            break;
    }

    UVC_AP1302_I2C_Read(0x60A4, sen_data);

    return 0;
}
int VizionCam::GetUSBFirmwareVersion(BYTE *fw_ver_data)
{
    ULONG readCount;

    BYTE GenI2CRead[EU1_TEST_CMD_LEN];
    struct uvc_xu_control_query xu_ctrl_query_write = {
        .unit     = UVC_XU_ID,
        .selector = EU1_TEST_CMD,
        .query    = UVC_SET_CUR,
        .size     = EU1_TEST_CMD_LEN,
        .data     = NULL,
    };

    struct uvc_xu_control_query xu_ctrl_query_read = {
        .unit     = UVC_XU_ID,
        .selector = EU1_TEST_CMD,
        .query    = UVC_GET_CUR,
        .size     = EU1_TEST_CMD_LEN,
        .data     = NULL,
    };


    xu_ctrl_query_write.data = fw_ver_data;
    xu_ctrl_query_read.data = fw_ver_data;




    if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read)!= 0) {
        printf("read query fail!\n");
        printf("%s\n", strerror(errno));
        return -1;
    }


//    std::cout << "GetUSBFirmwareVersion++++data HEX :" << std::hex << static_cast<int>(*fw_ver_data) << std::endl;

    return 0;


}
int VizionCam::GetUSBFirmwareVersion(char *fw_ver)
{
    ULONG readCount;
    BYTE fw_ver_data[4];
    BYTE GenI2CRead[EU1_TEST_CMD_LEN];
    struct uvc_xu_control_query xu_ctrl_query_write = {
        .unit     = UVC_XU_ID,
        .selector = EU1_TEST_CMD,
        .query    = UVC_SET_CUR,
        .size     = EU1_TEST_CMD_LEN,
        .data     = NULL,
    };

    struct uvc_xu_control_query xu_ctrl_query_read = {
        .unit     = UVC_XU_ID,
        .selector = EU1_TEST_CMD,
        .query    = UVC_GET_CUR,
        .size     = EU1_TEST_CMD_LEN,
        .data     = NULL,
    };


    xu_ctrl_query_write.data = fw_ver_data;
    xu_ctrl_query_read.data = fw_ver_data;




    if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read) != 0) {
        printf("read query fail!\n");
        printf("%s\n", strerror(errno));

        xu_ctrl_query_read.size=2;
        printf("size change to 2!\n");
        if (ioctl(fd, UVCIOC_CTRL_QUERY, &xu_ctrl_query_read) != 0){
            error_handle_extension_unit();
            return -1;
          }

    }

//    std::cout << "sizeof (fw_ver_data)::" <<sizeof (fw_ver_data) << std::endl;


#ifndef SHOW_BETA
		snprintf(fw_ver, 16, "%02d.%02d.%02d.%02d", fw_ver_data[0], fw_ver_data[1], fw_ver_data[2], fw_ver_data[3]);
#else
		if (fw_ver_data[2] == 0)
			snprintf(fw_ver, 16, "%02d.%02d\n", fw_ver_data[0], fw_ver_data[1]);
		else
			snprintf(fw_ver, 16, "%02d.%02d.beta%d", fw_ver_data[0], fw_ver_data[1], fw_ver_data[3]);
#endif

   //std::cout << "GetUSBFirmwareVersion++++data HEX :" << std::hex << static_cast<int>(*fw_ver) << std::endl;

    return 0;


}



int VizionCam::SetSpdlogPath(const char *log_path)
{

    std::string path(log_path);
    if (path.back() != '/') {
        path += '/';
    }
    std::string origin_log_file = "VizionSDK.log";

    logpath = path;
    std::string destination_log_file =logpath+"VizionSDK.log";
#ifdef IMX
//    if (std::filesystem::exists(origin_log_file)) {
//        std::filesystem::rename(origin_log_file, destination_log_file);
//    }
#endif
    logger = spdlog::rotating_logger_mt("VizionSDK:", logpath + "VizionSDK.log", 20971520, 3);
    return 0;

}
//::experimental


//Cypress Firmware Download
int VcStartFWDownload(FX3_FW_TARGET tgt, char* tatgetimg)
{
  int r, i;
  bool flag = false;
  cyusb_handle *h;
  std::string tgt_str;

  if ((tatgetimg == NULL) || (tgt == FX3_FW_TARGET::FW_TARGET_NONE)) {
                  fprintf (stderr, "Error: Firmware binary or target not specified\n");

                  return -EINVAL;
          }
  r = cyusb_open ();
  if (r < 0) {
               fprintf (stderr, "Error opening library\n");
               return -ENODEV;
          }
          else if (r == 0) {
                  fprintf (stderr, "Error: No FX3 device found\n");
                  return -ENODEV;
          }
          else if (r > 1) {
                  fprintf (stderr, "Error: More than one Cypress device found\n");
                  return -EINVAL;
          }

          h = cyusb_gethandle (0);

          switch (tgt) {
                  case FX3_FW_TARGET::FW_TARGET_RAM:
                         r = fx3_usbboot_download (h, tatgetimg);
                          break;
                  case FX3_FW_TARGET::FW_TARGET_I2C:
                          r = fx3_i2cboot_download (h, tatgetimg);
                          break;
                  case FX3_FW_TARGET::FW_TARGET_SPI:
                        r = fx3_spiboot_download (h, tatgetimg);
//                        std::cout << "+++FW_TARGET_SPI finish++++" << std::endl;

                          break;
                  default:
                          break;
          }
          if (r != 0) {
                  fprintf (stderr, "Error: FX3 firmware programming failed\n");
          } else {
                  printf ("FX3 firmware programming  completed\n");
          }

          if (r == 0)
          {
              uint8_t buf[1];

              std::this_thread::sleep_for(std::chrono::milliseconds(100));
              cyusb_control_transfer(h, 0x40, 0xB1, 0x0000, 0x0000, buf, sizeof(buf), 1000); // Reset by firmware

              //printf("Info : Programming to %s completed\n", tgt_str.c_str());
          }
          else
          {
              std::stringstream sstr;
              sstr.str("");
              sstr << "\nError: Firmware download failed unexpectedly with error code: " << m_FWDWNLOAD_ERROR_MSG[r];
              std::cout << sstr.str() << std::endl;
              if (tgt == FX3_FW_TARGET::FW_TARGET_SPI)
              {
                  printf("Info : Please verify the connection to external SPI device\n");
                  printf("Note : CYUSB3KIT-003 EZ-USB FX3 SuperSpeed Explorer Kit does not have onboard SPI FLASH\n");
              }



          }

//  std::cout << "+++VcStartFWDownload finish++++" << std::endl;



  return r;
}

static int fx3_ram_write (
		cyusb_handle  *h,
		unsigned char *buf,
		unsigned int   ramAddress,
		int            len)
{
	int r;
	int index = 0;
	int size;

	while (len > 0) {
		size = (len > MAX_WRITE_SIZE) ? MAX_WRITE_SIZE : len;
		r = cyusb_control_transfer (h, 0x40, 0xA0, GET_LSW(ramAddress), GET_MSW(ramAddress),
				&buf[index], size, VENDORCMD_TIMEOUT);
		if (r != size) {
			fprintf (stderr, "Error: Vendor write to FX3 RAM failed\n");
			return -1;
		}

		ramAddress += size;
		index      += size;
		len        -= size;
	}

	return 0;
}

/* Read the firmware image from the file into a buffer. */
static int read_firmware_image (
		const char    *filename,
		unsigned char *buf,
		int           *romsize,
		int           *filesize)
{
	int fd;
	int nbr;
	struct stat filestat;

	if (stat (filename, &filestat) != 0) {
		fprintf (stderr, "Error: Failed to stat file %s\n", filename);
		return -1;
	}

	// Verify that the file size does not exceed our limits.
	*filesize = filestat.st_size;
	if (*filesize > MAX_FWIMG_SIZE) {
		fprintf (stderr, "Error: File size exceeds maximum firmware image size\n");
		return -2;
	}

	fd = open (filename, O_RDONLY);
	if (fd < 0) {
		fprintf (stderr, "Error: File not found\n");
		return -3;
	}
	nbr = read (fd, buf, 2);		/* Read first 2 bytes, must be equal to 'CY'	*/
	if (strncmp ((char *)buf,"CY",2)) {
		fprintf (stderr, "Error: Image does not have 'CY' at start.\n");
		return -4;
	}
	nbr = read (fd, buf, 1);		/* Read 1 byte. bImageCTL	*/
	if (buf[0] & 0x01) {
		fprintf (stderr, "Error: Image does not contain executable code\n");
		return -5;
	}
	if (romsize != 0)
		*romsize = i2c_eeprom_size[(buf[0] >> 1) & 0x07];

	nbr = read (fd, buf, 1);		/* Read 1 byte. bImageType	*/
	if (!(buf[0] == 0xB0)) {
		fprintf (stderr, "Error: Not a normal FW binary with checksum\n");
		return -6;
	}

	// Read the complete firmware binary into a local buffer.
	lseek (fd, 0, SEEK_SET);
	nbr = read (fd, buf, *filesize);

	close (fd);
	return 0;
}

static int fx3_usbboot_download (
		cyusb_handle *h,
		const char   *filename)
{
	unsigned char *fwBuf;
	unsigned int  *data_p;
	unsigned int i, checksum;
	unsigned int address, length;
	int r, index, filesize;


	fwBuf = (unsigned char *)calloc (1, MAX_FWIMG_SIZE);
	if (fwBuf == 0) {
		fprintf (stderr, "Error: Failed to allocate buffer to store firmware binary\n");
		return -1;
	}

	// Read the firmware image into the local RAM buffer.
	r = read_firmware_image (filename, fwBuf, NULL, &filesize);
	if (r != 0) {
		fprintf (stderr, "Error: Failed to read firmware file %s\n", filename);
		free (fwBuf);
		return -2;
	}

	// Run through each section of code, and use vendor commands to download them to RAM.
	index    = 4;
	checksum = 0;
	while (index < filesize) {
		data_p  = (unsigned int *)(fwBuf + index);
		length  = data_p[0];
		address = data_p[1];
		if (length != 0) {
			for (i = 0; i < length; i++)
				checksum += data_p[2 + i];
			r = fx3_ram_write (h, fwBuf + index + 8, address, length * 4);
			if (r != 0) {
				fprintf (stderr, "Error: Failed to download data to FX3 RAM\n");
				free (fwBuf);
				return -3;
			}
		} else {
			if (checksum != data_p[2]) {
				fprintf (stderr, "Error: Checksum error in firmware binary\n");
				free (fwBuf);
				return -4;
			}

			r = cyusb_control_transfer (h, 0x40, 0xA0, GET_LSW(address), GET_MSW(address), NULL,
					0, VENDORCMD_TIMEOUT);
			if (r != 0)
				printf ("Info: Ignored error in control transfer: %d\n", r);
			break;
		}

		index += (8 + length * 4);
	}

	free (fwBuf);
	return 0;
}

/* Check if the current device handle corresponds to the FX3 flash programmer. */
static int check_fx3_flashprog (cyusb_handle *handle)
{
	int r;
	char local[8];

	r = cyusb_control_transfer (handle, 0xC0, 0xB0, 0, 0, (unsigned char *)local, 8, VENDORCMD_TIMEOUT);
	if ((r != 8) || (strncasecmp (local, "FX3PROG", 7) != 0)) {
		printf ("Info: Current device is not the FX3 flash programmer\n");
		return -1;
	}

	printf ("Info: Found FX3 flash programmer\n");
	return 0;
}

/* Get the handle to the FX3 flash programmer device, if found. */
static int get_fx3_prog_handle (
		cyusb_handle **h)
{
	char *progfile_p, *tmp;
	cyusb_handle *handle;
	int i, j, r;
	struct stat filestat;

	handle = *h;
	r = check_fx3_flashprog (handle);
	if (r == 0)
		return 0;

	printf ("Info: Trying to download flash programmer to RAM\n");

	tmp = getenv ("CYUSB_ROOT");
	if (tmp != NULL) {
		i = strlen (tmp);
		progfile_p = (char *)malloc (i + 32);
		strcpy (progfile_p, tmp);
		strcat (progfile_p, "/fx3_images/cyfxflashprog.img");
	}
	else {
		progfile_p = (char *)malloc (32);
		strcpy (progfile_p, "fx3_images/cyfxflashprog.img");
	}

	r = stat (progfile_p, &filestat);
	if (r != 0) {
		fprintf (stderr, "Error: Failed to find cyfxflashprog.img file\n");
		return -1;
	}

	r = fx3_usbboot_download (handle, progfile_p);
	free (progfile_p);
	if (r != 0) {
		fprintf (stderr, "Error: Failed to download flash prog utility\n");
		return -1;
	}

	cyusb_close ();
	*h = NULL;

	// Now wait for the flash programmer to enumerate, and get a handle to it.
	for (j = 0; j < GETHANDLE_TIMEOUT; j++) {
		sleep (1);
		r = cyusb_open ();
		if (r > 0) {
			for (i = 0; i < r; i++) {
				handle = cyusb_gethandle (i);
				if (cyusb_getvendor (handle) == FLASHPROG_VID) {
					r = check_fx3_flashprog (handle);
					if (r == 0) {
						printf ("Info: Got handle to FX3 flash programmer\n");
						*h = handle;
						return 0;
					}
				}
			}
			cyusb_close ();
		}
	}

	fprintf (stderr, "Error: Failed to get handle to flash programmer\n");
	return -2;
}

static int fx3_i2c_write (
		cyusb_handle  *h,
		unsigned char *buf,
		int            devAddr,
		int            start,
		int            len)
{
	int r = 0;
	int index = start;
	unsigned short address = 0;
	int size;

	while (len > 0) {
		size = (len > MAX_WRITE_SIZE) ? MAX_WRITE_SIZE : len;
		r = cyusb_control_transfer (h, 0x40, 0xBA, devAddr, address, &buf[index], size, VENDORCMD_TIMEOUT);
		if (r != size) {
			fprintf (stderr, "Error: I2C write failed\n");
			return -1;
		}

		address += size ;
		index   += size;
		len     -= size;
	}

	return 0;
}

/* Function to read I2C data and compare against the expected value. */
static int fx3_i2c_read_verify (
		cyusb_handle  *h,
		unsigned char *expData,
		int            devAddr,
		int            len)
{
	int r = 0;
	int index = 0;
	unsigned short address = 0;
	int size;
	unsigned char tmpBuf[MAX_WRITE_SIZE];

	while (len > 0) {
		size = (len > MAX_WRITE_SIZE) ? MAX_WRITE_SIZE : len;
		r = cyusb_control_transfer (h, 0xC0, 0xBB, devAddr, address, tmpBuf, size, VENDORCMD_TIMEOUT);
		if (r != size) {
			fprintf (stderr, "Error: I2C read failed\n");
			return -1;
		}

		if (memcmp (expData + index, tmpBuf, size) != 0) {
			fprintf (stderr, "Error: Failed to read expected data from I2C EEPROM\n");
			return -2;
		}

		address += size ;
		index   += size;
		len     -= size;
	}

	return 0;
}

int fx3_i2cboot_download (cyusb_handle *h,const char   *filename)
{
	int romsize, size;
	int address = 0, offset = 0;
	int r, filesize;
	unsigned char *fwBuf = 0;

	// Check if we have a handle to the FX3 flash programmer.
	r = get_fx3_prog_handle (&h);
	if (r != 0) {
		fprintf (stderr, "Error: FX3 flash programmer not found\n");
		return -1;
	}

	// Allocate memory for holding the firmware binary.
	fwBuf = (unsigned char *)calloc (1, MAX_FWIMG_SIZE);

	if (read_firmware_image (filename, fwBuf, &romsize, &filesize)) {
		fprintf (stderr, "Error: File %s does not contain valid FX3 firmware image\n", filename);
		free (fwBuf);
		return -2;
	}

	printf ("Info: Writing firmware image to I2C EEPROM\n");

	filesize = ROUND_UP(filesize, I2C_PAGE_SIZE);
	while (filesize != 0) {

		size = (filesize <= romsize) ? filesize : romsize;
		if (size > I2C_SLAVE_SIZE) {
			r = fx3_i2c_write (h, fwBuf, address, offset, I2C_SLAVE_SIZE);
			if (r == 0) {
				r = fx3_i2c_read_verify (h, fwBuf + offset, address, I2C_SLAVE_SIZE);
				if (r != 0) {
					fprintf (stderr, "Error: Read-verify from I2C EEPROM failed\n");
					free (fwBuf);
					return -3;
				}

				r = fx3_i2c_write (h, fwBuf, address + 4, offset + I2C_SLAVE_SIZE, size - I2C_SLAVE_SIZE);
				if (r == 0) {
					r = fx3_i2c_read_verify (h, fwBuf + offset + I2C_SLAVE_SIZE,
							address + 4, size - I2C_SLAVE_SIZE);
					if (r != 0) {
						fprintf (stderr, "Error: Read-verify from I2C EEPROM failed\n");
						free (fwBuf);
						return -3;
					}
				}
			}
		} else {
			r = fx3_i2c_write (h, fwBuf, address, offset, size);
			if (r == 0) {
				r = fx3_i2c_read_verify (h, fwBuf + offset, address, size);
				if (r != 0) {
					fprintf (stderr, "Error: Read-verify from I2C EEPROM failed\n");
					free (fwBuf);
					return -3;
				}
			}
		}

		if (r != 0) {
			fprintf (stderr, "Error: Write to I2C EEPROM failed\n");
			free (fwBuf);
			return -4;
		}

		/* Move to the next slave address. */
		offset += size;
		filesize -= size;
		address++;
	}

        free (fwBuf);
        printf ("Info: I2C programming completed\n");
        return 0;
}

static int fx3_spi_write (
		cyusb_handle  *h,
		unsigned char *buf,
		int            len)
{
	int r = 0;
	int index = 0;
	int size;
	unsigned short page_address = 0;

	while (len > 0) {
		size = (len > MAX_WRITE_SIZE) ? MAX_WRITE_SIZE : len;
		r = cyusb_control_transfer (h, 0x40, 0xC2, 0, page_address, &buf[index], size, VENDORCMD_TIMEOUT);
		if (r != size) {
			fprintf (stderr, "Error: Write to SPI flash failed\n");
			return -1;
		}
		index += size;
		len   -= size;
		page_address += (size / SPI_PAGE_SIZE);
	}

	return 0;
}

static int fx3_spi_erase_sector (
		cyusb_handle   *h,
		unsigned short  nsector)
{
	unsigned char stat;
	int           timeout = 10;
	int r;

	r = cyusb_control_transfer (h, 0x40, 0xC4, 1, nsector, NULL, 0, VENDORCMD_TIMEOUT);
	if (r != 0) {
		fprintf (stderr, "Error: SPI sector erase failed\n");
		return -1;
	}

	// Wait for the SPI flash to become ready again.
	do {
		r = cyusb_control_transfer (h, 0xC0, 0xC4, 0, 0, &stat, 1, VENDORCMD_TIMEOUT);
		if (r != 1) {
			fprintf (stderr, "Error: SPI status read failed\n");
			return -2;
		}
		sleep (1);
		timeout--;
	} while ((stat != 0) && (timeout > 0));

	if (stat != 0) {
		fprintf (stderr, "Error: Timed out on SPI status read\n");
		return -3;
	}

	printf ("Info: Erased sector %d of SPI flash\n", nsector);
	return 0;
}

int fx3_spiboot_download (
		cyusb_handle *h,
		const char   *filename)
{
	unsigned char *fwBuf;
	int r, i, filesize;

	// Check if we have a handle to the FX3 flash programmer.
	r = get_fx3_prog_handle (&h);
	if (r != 0) {
		fprintf (stderr, "Error: FX3 flash programmer not found\n");
		return -1;
	}

	// Allocate memory for holding the firmware binary.
	fwBuf = (unsigned char *)calloc (1, MAX_FWIMG_SIZE);
	if (fwBuf == 0) {
		fprintf (stderr, "Error: Failed to allocate buffer to store firmware binary\n");
		return -2;
	}

	if (read_firmware_image (filename, fwBuf, NULL, &filesize)) {
		fprintf (stderr, "Error: File %s does not contain valid FX3 firmware image\n", filename);
		free (fwBuf);
		return -3;
	}

	filesize = ROUND_UP(filesize, SPI_PAGE_SIZE);

	// Erase as many SPI sectors as are required to hold the firmware binary.
	for (i = 0; i < ((filesize + SPI_SECTOR_SIZE - 1) / SPI_SECTOR_SIZE); i++) {
		r = fx3_spi_erase_sector (h, i);
		if (r != 0) {
			fprintf (stderr, "Error: Failed to erase SPI flash\n");
			free (fwBuf);
			return -4;
		}
	}

	r = fx3_spi_write (h, fwBuf, filesize);
	if (r != 0) {
		fprintf (stderr, "Error: SPI write failed\n");
	} else {
		printf ("Info: SPI flash programming completed\n");
	}

	free (fwBuf);
	return r;
}

void print_usage_info (
		const char *arg0)
{
	printf ("%s: FX3 firmware programmer\n\n", arg0);
	printf ("Usage:\n");
	printf ("\t%s -h: Print this help message\n\n", arg0);
	printf ("\t%s -t <target> -i <img filename>: Program firmware binary from <img filename>\n", arg0);
	printf ("\t\tto <target>\n");
	printf ("\t\t\twhere <target> is one of\n");
	printf ("\t\t\t\t\"RAM\": Program to FX3 RAM\n");
	printf ("\t\t\t\t\"I2C\": Program to I2C EEPROM\n");
	printf ("\t\t\t\t\"SPI\": Program to SPI FLASH\n");
	printf ("\n\n");
}





int VcGetAutoExposureMode(VizionCam *vizion_cam, AE_MODE_STATUS &ae_mode)
{
    return vizion_cam->GetAutoExposureMode(ae_mode);
}
int VcSetAutoExposureMode(VizionCam *vizion_cam, AE_MODE_STATUS ae_mode)
{
    return vizion_cam->SetAutoExposureMode(ae_mode);
}
int VcUVC_AP1302_I2C_Read(VizionCam *vizion_cam, uint16_t addrReg, uint16_t &data)
{
    return vizion_cam->UVC_AP1302_I2C_Read(addrReg, data);
}

int VcUVC_AP1302_I2C_Write(VizionCam *vizion_cam, uint16_t addrReg, uint16_t data)
{
    return vizion_cam->UVC_AP1302_I2C_Write(addrReg, data);
}
int VcGetExposureTime(VizionCam *vizion_cam, uint32_t &exptime)
{
    return vizion_cam->GetExposureTime(exptime);
}
int VcSetExposureTime(VizionCam *vizion_cam, uint32_t exptime)
{
    return vizion_cam->SetExposureTime(exptime);
}

int VcGetExposureGain(VizionCam *vizion_cam, uint8_t &expgain)
{
    return vizion_cam->GetExposureGain(expgain);
}

int VcSetExposureGain(VizionCam *vizion_cam, uint8_t expgain)
{
    return vizion_cam->SetExposureGain(expgain);
}

int VcGetAutoWhiteBalanceMode(VizionCam *vizion_cam, AWB_MODE_STATUS &awb_mode)
{
    return vizion_cam->GetAutoWhiteBalanceMode(awb_mode);
}

int VcSetAutoWhiteBalanceMode(VizionCam *vizion_cam, AWB_MODE_STATUS awb_mode)
{
    return vizion_cam->SetAutoWhiteBalanceMode(awb_mode);
}

int VcGetTemperature(VizionCam *vizion_cam, uint16_t &temp)
{
    return vizion_cam->GetTemperature(temp);
}

int VcSetTemperature(VizionCam *vizion_cam, uint16_t temp)
{
    return vizion_cam->SetTemperature(temp);
}

int VcGetGamma(VizionCam *vizion_cam, double &gamma)
{
    return vizion_cam->GetGamma(gamma);
}

int VcSetGamma(VizionCam *vizion_cam, double gamma)
{
    return vizion_cam->SetGamma(gamma);
}

int VcGetSaturation(VizionCam *vizion_cam, double &saturation)
{
    return vizion_cam->GetSaturation(saturation);
}

int VcSetSaturation(VizionCam *vizion_cam, double saturation)
{
    return vizion_cam->SetSaturation(saturation);
}

int VcGetContrast(VizionCam *vizion_cam, double &contrast)
{
    return vizion_cam->GetContrast(contrast);
}

int VcSetContrast(VizionCam *vizion_cam, double contrast)
{
    return vizion_cam->SetContrast(contrast);
}

int VcGetSharpening(VizionCam *vizion_cam, double &sharpness)
{
    return vizion_cam->GetSharpening(sharpness);
}

int VcSetSharpening(VizionCam *vizion_cam, double sharpness)
{
    return vizion_cam->SetSharpening(sharpness);
}

int VcGetDenoise(VizionCam *vizion_cam, double &denoise)
{
    return vizion_cam->GetDenoise(denoise);
}

int VcSetDenoise(VizionCam *vizion_cam, double denoise)
{
    return vizion_cam->SetDenoise(denoise);
}

int VcGetDigitalZoomType(VizionCam *vizion_cam, DZ_MODE_STATUS &zoom_type)
{
    return vizion_cam->GetDigitalZoomType(zoom_type);
}

int VcSetDigitalZoomType(VizionCam *vizion_cam, DZ_MODE_STATUS zoom_type)
{
    return vizion_cam->SetDigitalZoomType(zoom_type);
}

int VcGetDigitalZoomTarget(VizionCam *vizion_cam, double &times)
{
    return vizion_cam->GetDigitalZoomTarget(times);
}

int VcSetDigitalZoomTarget(VizionCam *vizion_cam, double times)
{
    return vizion_cam->SetDigitalZoomTarget(times);
}
int VcGetDigitalZoom_CT_X(VizionCam *vizion_cam, double &ct_x)
{
    return vizion_cam->GetDigitalZoom_CT_X(ct_x);
}

int VcSetDigitalZoom_CT_X(VizionCam *vizion_cam, double ct_x)
{
    return vizion_cam->SetDigitalZoom_CT_X(ct_x);
}

int VcGetDigitalZoom_CT_Y(VizionCam *vizion_cam, double &ct_y)
{
    return vizion_cam->GetDigitalZoom_CT_Y(ct_y);
}

int VcSetDigitalZoom_CT_Y(VizionCam *vizion_cam, double ct_y)
{
    return vizion_cam->SetDigitalZoom_CT_Y(ct_y);
}

int VcGetFlipMode(VizionCam *vizion_cam, FLIP_MODE &flip)
{
    return vizion_cam->GetFlipMode(flip);
}

int VcSetFlipMode(VizionCam *vizion_cam, FLIP_MODE flip)
{
    return vizion_cam->SetFlipMode(flip);
}
int VcGetEffectMode(VizionCam *vizion_cam, EFFECT_MODE &effect)
{
    return vizion_cam->GetEffectMode(effect);
}
int VcSetEffectMode(VizionCam *vizion_cam, EFFECT_MODE effect)
{
    return vizion_cam->SetEffectMode(effect);
}
int VcGetBacklightCompensation(VizionCam *vizion_cam, double &ae_comp)
{
    return vizion_cam->GetBacklightCompensation(ae_comp);
}
int VcSetBacklightCompensation(VizionCam *vizion_cam, double ae_comp)
{
    return vizion_cam->SetBacklightCompensation(ae_comp);
}
int VcGetMaxFPS(VizionCam *vizion_cam, uint8_t &max_fps)
{
    return vizion_cam->GetMaxFPS(max_fps);
}

int VcSetMaxFPS(VizionCam *vizion_cam, uint8_t max_fps)
{
    return vizion_cam->SetMaxFPS(max_fps);
}
int VcRecoverDefaultSetting(VizionCam *vizion_cam)
{
    return vizion_cam->RecoverDefaultSetting();
}

int VcLoadProfileSetting(VizionCam *vizion_cam, const char *profile_str)
{
    return vizion_cam->LoadProfileSetting(profile_str);
}

int VcLoadProfileSettingFromPath(VizionCam *vizion_cam, const char *profile_path)
{
    return vizion_cam->LoadProfileSettingFromPath(profile_path);
}

int VcSetProfileStreamingConfig(VizionCam *vizion_cam)
{
    return vizion_cam->SetProfileStreamingConfig();
}

int VcSetProfileControlConfig(VizionCam *vizion_cam)
{
    return vizion_cam->SetProfileControlConfig();
}


int VcSetPropertyValue(VizionCam *vizion_cam, CAPTURE_PROPETIES prop_id, long value, int flag)
{
    return vizion_cam->SetPropertyValue(prop_id, value, flag);
}

int VcGetPropertyValue(VizionCam *vizion_cam, CAPTURE_PROPETIES prop_id, long &value, int &flag)
{
    return vizion_cam->GetPropertyValue(prop_id, value, flag);
}

int VcGetPropertyRange(VizionCam *vizion_cam, CAPTURE_PROPETIES prop_id, long &min, long &max, long &step, long &def, long &caps)
{
    return vizion_cam->GetPropertyRange(prop_id, min, max, step, def, caps);
}

int VcGetBootdataHeader(VizionCam *vizion_cam, VzHeader *header)
{
    return vizion_cam->GetBootdataHeader(header);
}
VIZION_API int VcGetBootdataHeaderV3(VizionCam *vizion_cam, VzHeaderV3 *header)
{
    return vizion_cam->GetBootdataHeaderV3(header);
}

VIZION_API int VcCheckHeaderVer(VizionCam *vizion_cam)
{
    return vizion_cam->CheckHeaderVer();
}

int VcGetDeviceHardwareID(VizionCam *vizion_cam, wchar_t *hardware_id)
{
    return vizion_cam->GetDeviceHardwareID(hardware_id);
}

int VcClearISPBootdata(VizionCam *vizion_cam)
{
    return vizion_cam->ClearISPBootdata();
}

int VcDownloadBootdata(VizionCam *vizion_cam, const char *binfilepath)
{
    return vizion_cam->DownloadBootdata(binfilepath);
}
int VcGotoProgramMode(VizionCam *vizion_cam)
{
    return vizion_cam->GotoProgramMode();
}
void VcGetDeviceSpeed(VizionCam *vizion_cam, USB_DEVICE_SPEED &usb_speed)
{
    vizion_cam->GetDeviceSpeed(usb_speed);
}
int VcGetUniqueSensorID(VizionCam *vizion_cam, char *sensor_id)
{
    return vizion_cam->GetUniqueSensorID(sensor_id);
}
int VcGetUSBFirmwareVersion(VizionCam* vizion_cam, char* fw_ver)
{
        return vizion_cam->GetUSBFirmwareVersion(fw_ver);
}
int VcSetSpdlogPath(VizionCam *vizion_cam, const char *log_path)
{

    return vizion_cam->SetSpdlogPath(log_path);
}

int VcLinuxI2CRead(VizionCam* vizion_cam,uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t* data){

  return vizion_cam->LinuxI2CRead( slvaddr,  reglen,  regaddr,  datalen,  data);
}
int VcLinuxI2CWrite(VizionCam* vizion_cam,uint8_t slvaddr, uint8_t reglen, uint16_t regaddr, uint16_t datalen, uint8_t* data){

  return vizion_cam->LinuxI2CWrite( slvaddr,  reglen,  regaddr,  datalen,  data);
}


int VcGetVizionCamDeviceName(VizionCam *vizion_cam, wchar_t *devname)
{
    return vizion_cam->GetVizionCamDeviceName(devname);
}

int VcOpen(VizionCam *vizion_cam, int dev_idx)
{
    return vizion_cam->Open(dev_idx);
}

int VcClose(VizionCam *vizion_cam)
{
    return vizion_cam->Close();
}
int VcGetVideoDeviceList(VizionCam *vizion_cam, std::vector<std::wstring> &devname_list)
{
    return vizion_cam->GetVideoDeviceList(devname_list);
}


int VcGetCaptureFormatList(VizionCam *vizion_cam, std::vector<VzFormat> &capformats)
{
    return vizion_cam->GetCaptureFormatList(capformats);
}

int VcGetCurrentExposureGain(VizionCam* vizion_cam, uint8_t& expgain)
{
    return vizion_cam->GetCurrentExposureGain(expgain);
}

int VcGetCurrentExposureTime(VizionCam* vizion_cam, uint32_t& exptime)
{
    return vizion_cam->GetCurrentExposureTime(exptime);
}




